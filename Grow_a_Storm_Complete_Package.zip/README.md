# Grow a Storm — garden overhaul

**Open `Grow_a_Storm.rbxl` in Roblox Studio and press Play.** This substantially improves the existing game; it preserves its identity, six weather destinations, progress/save key and authoritative economy/receipt foundations. The native place contains the complete map, modules, server, interface and client effects. No Rojo sync, plugin, Toolbox asset or external module loader is required to play it.

You receive one of eight cloud gardens, a starter cloud, and immediate landed/falling rain. Walk underneath your cloud to collect water, coins and energy. Buy Magnet for 35 coins, discover Rain Cloud at 60 energy, then select it in **Storms**. Visit the plaza or travel to weather islands. Rain Tempo accelerates production; Cloud Bays unlock extra producing clouds at 220/600 best energy. All eight storm types and all progression are available for free.

## What changed

- Eight assigned/released gardens around a cheerful grass plaza: readable ownership/progression signs, clean production floors, grow pads, colored borders and planting space.
- Original storm fountain monument, upgrade/index/ascension stations with genuine interaction prompts, radial paths, pond/stream, flowers, trees, rocks, weather instruments and an animated windmill. Outposts moved outward to keep the main garden layout clear.
- Fixed cloud-growing areas with owner-only, pooled, visibly falling collectibles; automatic recovery for missing/malformed/unanchored drops; independent startup and protected heartbeat stages.
- Eight persistent free storm discoveries/equipment, distinct geometry/VFX, six growth levels, new Rain Tempo and Cloud Bay upgrades, four themed weather events and persistent visual/audio settings.
- Complete pastel UI replacement: compact resource chips, outlined/gradient buttons, affordability/lock-aware shop cards, storm rarity/production/discovery cards with 3D previews, objectives, notices, scrollable panels and stable controller selection.
- Retained quests/gift, consenting co-op Storm Link, Forecast Ascension/stars, legacy migration, session leases, safe saving and atomic receipt transactions.

Read `docs/OVERHAUL_REPORT.md` for the audit, resolved issues, architecture and exact scope. The current governing request is `docs/UPDATED_OVERHAUL_SPEC.md`; the earlier metaprompt is retained as history.

## Open and play

1. Download the native `.rbxl`, or extract it from the complete package ZIP.
2. In Studio, choose **File → Open from File** and select `Grow_a_Storm.rbxl` (the ZIP also includes the equivalent XML `.rbxlx`).
3. Press **Play**. Your plot is assigned automatically. Follow the collection arrow/objective; collect rain and open Shop.
4. Use **Travel → My Cloud Garden** to return to your plot, or **Central Plaza** for the hub. Approach a plaza station and use its interaction prompt to open Shop/Storm Collection/Ascension.
5. Use **Storms** to discover/equip storm types. **Extras** has sound, motion/quality, color wardrobe, co-op and ascension controls.

The native place needs no account-specific IDs for core play. **Audio is disabled until the owner uploads the six included original WAVs and supplies real authorized IDs.** Optional purchases are also hidden until configured; they are never required for progress.

Set the live place's maximum player count to **8** in owner experience settings before testing/release. This account setting is separate from a local place file. Overflow is safely rejected with a clear message rather than leaving a ninth player without a functioning garden.

## Original assets and account setup

`audio/` contains original mono 24 kHz Music (32 seconds), Rain, Pickup, Evolve, Click and Thunder WAVs. Upload them using Studio Asset Manager or Creator Dashboard, wait for moderation, and grant the intended experience permission. Use only your actual assigned IDs. `SETUP_ASSET_IDS.luau` is an **Edit-mode-only** helper; edit its table, paste the whole file into the Command Bar while Play is stopped, then save the place and start a new Play session. You can alternatively edit `ReplicatedStorage.StormConfig` directly.

The optional Aurora color/halo pass is cosmetic; the free Aurora Storm catalog discovery remains obtainable by play. The developer product grants exactly 1,000 wallet coins with no energy/water or random reward. Real pass/product configuration, permission, localized prices, audio playback and live purchases need owner tests. None were performed here.

## Source and reproduction

| Location | Contents |
|---|---|
| ReplicatedStorage | StormConfig, StormEconomy, StormRain, StormProfiles, StormLink, StormPlots |
| ReplicatedStorage | StormAction, StormState, StormNotice |
| ServerScriptService | StormServer |
| StarterPlayer/StarterPlayerScripts | StormClient, StormWorld |
| Workspace | StormArchipelago, PlayerPlots, RainDrops, PersonalClouds, StarterSpawn |

From the checkout root on Linux x86_64:

```sh
bash tools/setup.sh
bash tools/check.sh
```

Requirements: Python 3, curl, unzip and sha256sum. Setup verifies the pinned official HTTPS Lune 0.11.0 archive; no sudo or secrets are needed. Checks regenerate original audio and both places from the backed-up existing place, execute production rules/embedded runtime/DOM suites, reject incomplete or stale results, and package/verify the ZIP. `dist/` contains both place formats and the complete archive. `models/` includes 16 native exports: six destinations, full archipelago, full plot group and eight individual gardens.

The optional offline map preview uses the actual native geometry exported by `tools/geometry_preview.luau`; run `python3 tools/preview.py` with NumPy/Pillow to regenerate its CPU visualization. This is not an engine screenshot and does not simulate Roblox materials, lighting, UI, particles or live clouds.

## Saves, security and performance

`GrowAStorm_v1` and decimal user ID keys are preserved. Legacy wallet, energy, upgrades, stars, receipts, tutorial, quests, gift timestamps and cosmetic state migrate; new fields retain storm discoveries/equipment, best energy, lifetime collected water and settings. Ascension keeps discoveries, water, settings, entitlements/receipts and daily cooldown while resetting coins/energy/upgrades/bay capacity. Wallet-only quest/gift/product grants never count as collected water or earned energy.

The server owns reward amounts, upgrade prices/limits, catalog equipment gates, plot ownership, travel, claims and cooldowns. Remote input is type/range checked and rate limited. Movement plausibility and authorized area checks supplement collection distance; these are proportional defenses, not comprehensive anti-cheat or grounds for arbitrary bans.

Five-minute session leases, protected controlled retries, roughly 70-second autosaves and a bounded 25-second shutdown save remain. Live loading failures reject safely; Studio can use explicitly labeled temporary profiles with paid purchases hidden. Atomic receipt grants pause mutations and persist the reward/marker together, including callback retries, redelivery and uncertain-result reconciliation. Ordinary crashes can lose progress since the last successful autosave.

There are 1,643 physical parts in the exported place, including 180 shared pooled collectibles. Eight players with three clouds each add at most 192 private pooled drops: 372 total gameplay drops. None rely on physics ownership. Motion is approximately 20 Hz and collection approximately 6.7 Hz. Static server clouds avoid per-frame cloud replication; client decorations cache relevant parts, run at ≤30 Hz (10 Hz on low effects), and reduce particle rates in low-effects mode. Actual phone FPS/memory remain unmeasured. Streaming stays disabled for reliability.

## Validation and troubleshooting

Read `tests/RESULTS.md` and `TESTING_AND_RELEASE.md`. Production-source/service-double and actual-DOM checks are distinct from Roblox Studio testing. This build is implemented and offline validated; no engine playtest, publication or release-readiness certification is claimed.

- No rain: inspect Studio Output first. Workspace `RainHeartbeat` must advance, `RainHealth` should be `Running`, and `ActiveRainDrops` should be within the pool bound. Leave all six modules and three remotes in ReplicatedStorage, and both client scripts in StarterPlayerScripts. Missing/unanchored/malformed managed pool objects automatically repair.
- Can't collect: use your own garden; another player's private drops cannot be stolen. Your character must be alive, close enough and within its authorized region. Recent implausible teleports cause a brief collection quarantine; Home/Travel provide authorized arrivals.
- Save failure: a Studio temporary profile is playable but not durable. Use a separate private test universe for real persistence checks. Do not remove live-load protections or delete existing progress to bypass a lease/load error.
- Audio silent or purchase missing: default zero IDs intentionally disable them. Check upload moderation, experience permissions, sale state/current price, settings and temporary/paused profile state.
- Plot full: configure a maximum of eight players. The allocator releases gardens on PlayerRemoving; a separate server is required for additional players.

`docs/Grow_a_Storm_Before_Overhaul.rbxl` restores the original place. The fuller verified source/Git/artifact checkpoint is recorded in `docs/CHECKPOINT.json`. No public Roblox publishing, uploads, Robux spending or live purchases occurred.
