# Grow a Storm 2.0

**Open `Grow_a_Storm.rbxl` in Roblox Studio and press Play.** The single native place contains the upgraded existing game: map, server, modules, interface, collectible rain and original native models. No plugin, Toolbox asset or source sync is needed for basic play.

The governing request is [the uploaded 2.0 specification](docs/GROW_A_STORM_2_0_SPEC.md). Earlier specifications are retained as history. This release preserves the working rain, original destinations, `GrowAStorm_v1` save key, durable receipt handling and plot ownership.

## Play

1. File → Open from File → `Grow_a_Storm.rbxl` → Play.
2. Walk beneath your assigned starter cloud. Falling drops give coins, stored water and earned progression energy. Gold drops pay more.
3. Open **Sanctuary → Garden Upgrades** for Magnet (35 coins). Open **Weather Market** to buy core licenses, then **Storm Encyclopedia → Cores** to plant one in a selected bay.
4. Visit the Equipment Workshop or use its screen to build a condenser. **Weather Engineering** controls temperature, humidity, wind and charge; devices and research expand available ranges.
5. Follow mutation recipe clues, claim Goals, advance Research and unlock laboratory terraces. **Forecast** shows global weather, community objectives, production sprints and Storm Chasing.
6. **My Garden** returns home. **Visit & Travel** visits occupied gardens and the original weather destinations. **Settings & Prestige** contains saved effects/audio settings, wardrobe, co-op and the prestige confirmation.

Set the experience's maximum player count to **eight** in Roblox owner settings. An extra player is safely rejected when all plots are occupied.

## What is implemented

- A landscaped floating sanctuary with eight private gardens, rolling meadows, water/flowers/trees, six themed public stations, an animated merchant and weather machinery. Progressing gardens add live devices, growing platforms, research terraces, laboratory canopies and prestige observatories.
- Twelve distinct storm types with three actual growth stages each, unique silhouettes, colors, speed/value/climate characteristics and native 3D collection and market previews.
- Permanent-stock core market, changing featured discounts, core-copy inventory, server-controlled growth, environmental fit, twelve devices with three levels, five research branches with three permanent levels, ten deterministic mutations and compatible paired variants.
- Three-tab encyclopedia, saved recipes/stages/research/achievements, eleven goals, daily quests, plot visits, public storm discoveries, collaborative weather, participation-based production sprints and skill/distance/cooldown validated Storm Chasing.
- Twenty Forecast Stars, permanent production benefits, laboratory/observatory layouts and a bonus bay at three stars. All storm cores, devices, research, mutation history and terrace expansions survive prestige.
- Compact resource HUD, expandable three-control navigation, shared design tokens, rounded surfaces, subtle strokes/gradients/shadows, state-aware cards, responsive scrolling, button/notice transitions, counted currencies, growth reveals and reduced-motion/low-effects settings.

Cores are reusable licenses; planting a **different** type resets that bay's growth and active mutations. Encyclopedia discoveries remain saved. Duplicate simultaneous placements require enough copies. All twelve storms remain obtainable through free play; optional trading is omitted.

## Resources and choices

| Resource | Source | Purpose |
|---|---|---|
| Coins | Collected rain, goals, daily rewards | Cores, garden upgrades, devices, research, terraces |
| Stored water | Collected rain; storage expands with condensers | Core purchases, machinery, experiments |
| Atmospheric energy | Thunder-tier and higher private rain, community events, sprints, chasing | Experiments and terrace expansion |
| Research points | First storm/mutation discoveries, goals, daily quests, community events, sprints, chasing | Five permanent research branches |

Best earned energy unlocks progression; it never falls when spending coins or prestiging. Lifetime water remains separate from spendable stored water. Wallet gifts and the optional fixed coin product do not grant earned energy, collected water or production competition credit.

`docs/BALANCE.json` contains calculations for every storm and all equipment/research costs. A deterministic actual-rain route reaches an upgrade at 8.85 seconds, a Rain core at 24.9 seconds, a condenser at 53.1 seconds, a second cloud at 92.55 seconds and mature growth at 150 seconds. These are simulation results with controlled walking, not measured human play times. HUD potential is a sustained floor-pickup estimate, excluding shared fields, weather and co-op; actual collected income depends on play.

## Original mesh and audio assets

The place uses original native layered models and is playable immediately. `meshes/` supplies **36 original OBJ/MTL exports** and the editable `Grow_a_Storm_Original_Clouds.blend`; clouds were actually voxel-fused and smoothed in Blender. The reviewed gallery is `docs/Blender_Cloud_Gallery.png`, a Blender render, not a Studio screenshot.

Using imported MeshParts requires the owner to import those assets with Studio's 3D Importer and associated account permissions. Group each stage as `Sunny_Stage1`, `Rain_Stage2`, etc., under `Workspace/ImportedStormMeshes`. In **Edit mode**, paste `SETUP_MESH_LIBRARY.luau` into the Command Bar, then save. The runtime and previews use valid imported templates when present and otherwise retain native models. Inspect pivots, scale, material and permissions before replacing all stages. OBJ orientation is exported for Roblox; do not treat the Blender gallery's row arrangement as asset placement.

Six original mono 24 kHz WAVs are included in `audio/`. Roblox audio defaults to disabled until owner uploads, moderation, experience permission and real assigned IDs. Configure those through the Edit-mode-only `SETUP_ASSET_IDS.luau` helper or `ReplicatedStorage.StormConfig`, save, then restart Play. An optional cosmetic Aurora pass and fixed 1,000-coin product also default to disabled IDs. No purchases are required for progress. No assets were uploaded to your account and no Roblox game was published.

## Validate or rebuild

```sh
bash tools/setup.sh
bash tools/check.sh
```

Run from the checkout/extracted package root on Linux x86_64. Requirements: Python 3, curl, unzip and sha256sum. Setup installs the SHA256-pinned official Lune 0.11.0 archive locally. Checks regenerate audio and both place formats, execute actual production modules and embedded scripts with service doubles, inspect native geometry/models, calculate balance, validate meshes and verify ZIP membership/hashes. Blender is needed only to regenerate mesh assets; NumPy/Pillow are needed only for the optional map preview.

`dist/` contains the final binary/XML places and complete ZIP. `src/` contains fourteen scripts; `models/` contains 64 native exports. The 36 storm/12 device template libraries live in **ServerStorage** to avoid unnecessary client replication. Eleven shared modules/remotes live in ReplicatedStorage, the server in ServerScriptService, and two local scripts in StarterPlayerScripts. Imported mesh templates use ReplicatedStorage for preview access.

**119 offline checks passed.** See `tests/RESULTS.md`, `docs/OVERHAUL_REPORT.md`, and `TESTING_AND_RELEASE.md`. These do not establish Studio appearance, real device FPS, live multiplayer, published persistence or account purchases.

Workspace contains 2,116 static parts, including 180 pooled shared drops. The complete DataModel contains 3,814 parts including stored libraries. Eight players with six bays add at most 384 private drops: **564 gameplay drops total**. Rain uses anchored server records; decorative motion stays on clients with cached objects and reduced effects settings. Streaming remains disabled; actual phone performance needs profiling.

The migration preserves recognized existing currencies, upgrades, receipts, stars and ownership; version-six fields add cores, devices, growth and journals. Existing simultaneously planted legacy cores are grandfathered. Five-minute session leases, controlled retry, approximately 70-second autosaves and bounded shutdown saves remain. Crashes may lose progress since the last successful save. Test durability in a separate private universe.

`docs/Grow_a_Storm_Pre_2_0.rbxl` restores the immediately preceding working game. `docs/Grow_a_Storm_Before_Overhaul.rbxl` preserves the earlier original. A verified complete pre-2.0 project/Git archive is also retained in the cloud workspace; its hash is recorded in the overhaul report.
