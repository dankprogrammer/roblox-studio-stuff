# Testing and remaining owner checks

This overhaul updates the existing game. A baseline run passed the original 50 offline checks before changes; the original native place and source/Git checkpoint were backed up first. The final reports in `tests/` are the authoritative evidence for the new implementation.

## Final offline checks

| Suite | Completed checks | What actually executed |
|---|---:|---|
| rules.luau | 29 | Actual economy/rain/profile/link/plot modules: motion/landing/claim locks/recovery; fresh earnings, upgrades/evolution/tutorial; gold/star/event rewards; migration/quests/gift/prestige; ownership/receipt serialization/failure/retry; plot allocation/overflow/release; private rain/equipment/settings/bays |
| runtime.luau | 26 | Actual scripts embedded in the final binary place, using Roblox DOM instances and explicit service/scheduler doubles: join/plots/clouds/rain, normal walking progression, shop/remotes/HUD, equipment/Tempo/bays, independent two-player rain/co-op, eight profiles/overflow, events, save/rejoin/settings, respawn/rescue, receipt failures, UI screens/notices/reinitialization, client decoration, malformed pool repair, shutdown |
| exports.luau | 10 | Both actual place formats deserialize; byte-exact final source/locations; native dimensions/packed colors/shapes/rotation/spawn/trail references; 16 native models; starter/plot lanes and arrivals; source/service/save-key preservation; plaza interactions; no duplicate scripts/remotes/loaders; guarded editor helper |
| package.py | 5 | Fresh completed suite reports; valid non-silent six WAVs; byte-exact original synthesis reproducibility; required assets/source/docs/model counts; ZIP CRCs/membership/hashes and nested artifact identities |

**70 checks** in the final successful run. Nine production scripts and the editor helper compile using Lune 0.11.0's Luau compiler. An absent, stale, partial or failed report is rejected; a zero-error exit without completed tests is not enough. These are not Roblox Studio Play tests.

UI layout bounds were computed at 320×568, 568×320, 768×1024, 1280×720 and 1920×1080. Primary panels/close controls and six navigation targets fit within those dimensions, with ≥44px touch targets. These checks do not measure actual glyph rendering, clipping under platform text settings, safe-area/notch behavior or console focus traversal.

The CPU preview shows actual exported native geometry with correct depth ordering. It does not render Studio lighting/materials/particles, UI or dynamically loaded player clouds. Headless service doubles cannot establish real DataStore throttling, replication, Humanoid physics, sound permission or account purchase behavior.

## Required owner/Studio checks — not run

1. **Local engine Play:** File → Open from File → Grow_a_Storm.rbxl → Play. Confirm assigned sign, starter cloud above its grow area, immediate reachable landed rain plus visible falling rain, water/coin/energy HUD, 35-coin Magnet purchase, continued production, 60-energy discovery and equipment. Watch Output and Workspace RainHeartbeat/RainHealth/ActiveRainDrops.
2. **Two actual clients:** Start Server with two players in Studio. Confirm different plots, owner-only drops, simultaneous independent progression, shared-field claim locking, cloud visibility/replication, co-op explicit opt-in/cancellation/distance/cooldowns, plot release, respawn and travel. The offline eight-profile simulation is not an actual multi-client engine session.
3. **Devices/controllers:** Use Studio Device Emulator and actual supported devices/controllers. Verify phone portrait/landscape/tablet/desktop screen bounds, actual text/safe-area clipping, scrolling, focus, close/backdrop/Back, touch targets, preview rendering, settings and animations. Test reduced motion and low effects, including dark/bright backgrounds and color readability.
4. **Cloud/economy/gameplay:** Reach all discoveries or use a separate test fixture. Inspect distinct effects, six growth models, three producing bays, new upgrade feedback and gated states. Review first-minute onboarding and longer-term balance with actual players; enjoyment/commercial-quality comparisons cannot be proven by these tests.
5. **Weather:** Confirm Heavy Rain/Thunderstorm/Rainbow/Blizzard countdowns, plot/destination bonuses, particles/tints, normal rain continuity and event end restoration. Avoid flashing or uncontrolled sound spikes.
6. **Performance:** Profile a mid-range phone and eight real clients. Measure frame time/memory/replication/particle costs with all bays active; target practical budgets based on actual results. Static exported parts are 1,643; gameplay pools are bounded at 372. No FPS guarantee is made. Set the live place's maximum player count to eight in owner settings.
7. **Durability:** Use a separate private test universe. Enable Studio API access only there; verify leave/rejoin, shutdown, outages/throttling, lease handoff/expiry, old saves, storm equipment/discovery, settings, UTC quests, gift and ascension. Never let Studio overwrite production saves; check any undocumented previous key prefixes/schema before real migration.
8. **Audio:** Upload the six original 24 kHz mono WAVs, pass moderation, grant experience usage permission, fill real IDs in the editor helper or StormConfig, save and restart Play. Listen to loops, volumes, UI/pickup/purchase/unlock/rain/thunder and toggle behavior in the private experience. Current IDs are zero; Roblox playback was not tested.
9. **Optional monetization:** Configure an experience-owned cosmetic pass and fixed wallet-only product, or keep IDs zero. Confirm current personalized prices, authoritative ownership and durable receipt grant/retry/redelivery/rejoin/failure. No live purchase/Robux expense occurred; that needs the owner's explicit decision.
10. **Release:** Recheck current Creator Hub audience/publishing eligibility, maturity/compliance, permissions, original icon/thumbnails/metadata and Community Standards. No public experience was published and no approval/policy certification is claimed.

## Current official documentation consulted

Official Roblox `creator-docs` was fetched on 2026-10-13 at commit `784c5e217446c65958d5d84f5c5f1d127951a8d7`. The implementation reviewed these actual pages/API references rather than relying only on memory:

- [ParticleEmitter](https://create.roblox.com/docs/reference/engine/classes/ParticleEmitter): bounded emission/lifetime, texture, direction/spread, size and Squash. Positive Squash makes vertically stretched rainfall; snow keeps square flakes. Gameplay does not rely on particles.
- [ViewportFrame](https://create.roblox.com/docs/ui/viewport-frames): separate camera/world geometry for native storm-card previews.
- [GuiButton](https://create.roblox.com/docs/reference/engine/classes/GuiButton): Activated supports mouse/touch/controller; event wiring belongs on the client.
- [ProximityPrompt](https://create.roblox.com/docs/reference/engine/classes/ProximityPrompt), [client-server boundary](https://create.roblox.com/docs/scripting/security/client-server-boundary): UI-opening prompts still validate server distance, as client-visible interaction settings are not authoritative.
- [UIStroke](https://create.roblox.com/docs/reference/engine/classes/UIStroke), [TweenService](https://create.roblox.com/docs/reference/engine/classes/TweenService): native borders and restrained local animations.
- [Player data/purchasing](https://create.roblox.com/docs/cloud-services/data-stores/player-data-purchasing), [DataStore best practices](https://create.roblox.com/docs/cloud-services/data-stores/best-practices): local profiles, periodic/final saves, session exclusion, UpdateAsync and durable receipt records.
- [Developer products](https://create.roblox.com/docs/production/monetization/developer-products), [passes](https://create.roblox.com/docs/production/monetization/passes): current client prices, authoritative ownership and ProcessReceipt fulfillment.
- [Audio assets](https://create.roblox.com/docs/audio/assets): original rights, formats/limits, assigned IDs, moderation and experience permission.
- [Publishing](https://create.roblox.com/docs/production/publishing/publish-games-and-places): private/public/limited access and audience-dependent eligibility/compliance. Owner eligibility and fees were not changed or attempted.

Original geometry/UI art/audio are supplied without Toolbox loaders or paid random rewards. Account-specific moderation, asset availability, sound playback and release compliance remain owner responsibilities and unverified capabilities, not completed setup claims.
