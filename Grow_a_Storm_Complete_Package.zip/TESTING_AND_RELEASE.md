# Tests run and remaining Roblox Studio checks

The uploaded `docs/GROW_A_STORM_2_0_SPEC.md` is the current request. Its Studio review instructions are conditional on tool access; no callable Roblox Studio connection is available here. The existing working place/source was audited, backed up and baseline-tested before the 2.0 implementation.

## Executed validation

| Suite | Checks | What actually runs |
|---|---:|---|
| Rules | 29 | Existing production economy, rain, profile, receipt, co-op and plot rules; regression protections |
| Science | 34 | Actual v6 migration, all twelve obtainable cores, copy gates, growth stages/climate, twelve devices, five research branches, ten deterministic mutation recipes, compatibility, no failed-spend grants, prestige, terraces, single-claim goals and alternate unlocks |
| Runtime | 32 | Actual final scripts embedded in the binary place with DOM instances and explicit service/scheduler doubles: falling rain and pickups, remotes, eight profiles/overflow, UI/settings/purchases, machinery/climate/research/mutations/terraces, encyclopedia tabs, visiting, Storm Chasing timing/distance/rewards, persistence/receipts, cleanup and shutdown |
| Exports | 12 | Binary/XML deserialization, byte-exact script placement, positive dimensions/colors/shapes/references, 64 loader-free native models, 36 stored growth templates, twelve device templates, six interactive stations, safe arrivals/collection lanes, preserved services/key, editor helper guards |
| Balance | 5 | Actual 600-second rain-route simulation, twelve rate calculations, all device/research costs, real Tempo/yield/luck effects and eight × six-bay pool bound/removal |
| Artifacts | 7 | Fresh complete reports, six valid non-silent WAVs and synthesis reproducibility, required assets/source/docs, all 36 distinct OBJ topologies/material dependencies/Blender source/gallery, balance output, ZIP CRCs/member identities/hashes |

**119 checks in the final successful run.** Fourteen production scripts and two Edit-mode helpers compile with Lune 0.11.0. A missing, partial, stale or failed suite rejects the package. Detailed evidence is in `tests/*-results.json`; `tests/RESULTS.md` records the final limitations.

UI bounding dimensions and touch sizes are checked at 320×568, 568×320, 768×1024, 1280×720 and 1920×1080. ViewportFrames, their cameras and original geometry are instantiated by the actual client source. This does **not** establish real rendering, text clipping, automatic canvas behavior, safe areas or focus across supported devices. The Blender gallery and CPU map preview were visually inspected; neither is a Roblox Studio screenshot.

The ten-minute simulation uses actual production code on a repeatable walking route, without gifts/global events/co-op. Magnet: 8.85s; new Rain core: 24.9s; condenser: 53.1s; second cloud: 92.55s; mature growth: 150s. It measures one deterministic route, not user understanding, fun, commercial quality or average retention. Prices/rates/costs are in `docs/BALANCE.json`.

## Required Studio/account checks — not run

1. **Local engine Play:** Open the native file. Confirm plot name, starter stage, immediately reachable landed rain plus visible falling droplets, coins/stored water, Magnet, Weather Market core purchase, encyclopedia planting and growth. Check Output and Workspace `RainHeartbeat`, `RainHealth` and `ActiveRainDrops`.
2. **UI visual review:** Use Device Emulator and real desktop/phone/tablet/controller devices. Capture and review screens for typography, spacing, clipping, safe-area behavior, preview framing, tab switching, automatic scrolling, keyboard/controller focus and closing. Test normal/reduced-motion/low-effects settings. Offline bounds are insufficient to approve appearance.
3. **Multiplayer:** Start Server with two then eight clients. Test distinct plots, private/shared claim rules, releases and empty garden restoration, simultaneous progression, consent-based co-op, visiting/showcases, public achievements/discoveries, server-time chasing accuracy, sprint rewards and community events.
4. **Cultivation and long-term balance:** Play all twelve storms and three stages, twelve devices/all upgrades, five research branches, ten recipes and compatible pairs, alternate event/achievement unlocks, research terraces and prestige. Test resetting a bay by planting a different type; preserve all discoveries. Check onboarding with actual new players and rebalance observed times.
5. **Events/effects:** Verify Golden Sky, Thunder Surge, Frozen Front, Aurora Night and Celestial Convergence, map tint/particles, ordinary production continuity, mutation highlights/orbits, equipment feedback and chase formation visibility. Capture/review animations; restrain flashing and clutter.
6. **Performance:** Profile a mid-range phone with eight players/six clouds each; measure render/frame time, memory, replication and particles. Workspace starts at 2,116 physical parts; server-stored libraries bring the DataModel to 3,814. Shared/private gameplay rain is bounded at 564 drops. These counts are not FPS guarantees. Set the owner experience player cap to eight.
7. **Persistence:** Use a separate private test universe. Verify legacy/v5/v6 saves, leave/rejoin, shutdown, lease handoff/expiry, throttling/outages, cores/growth/mutations/journals/research, single-claim goals, daily cooldowns and prestige preservation. Keep Studio away from production saves while testing.
8. **Meshes:** Optional: import the 36 original OBJ assets through the owner account, group/name/pivot each stage, run `SETUP_MESH_LIBRARY.luau` in Edit mode, save and check materials/scale/previews/gameplay and permissions in Play. This step was not performed; the native layered models already support complete core gameplay.
9. **Audio:** Upload the six included original WAVs, pass moderation, grant experience use and configure actual IDs via `SETUP_ASSET_IDS.luau` in Edit mode. Save/restart; inspect volume/loops/mute/restart behavior and distinct rain/thunder/reward sounds. Current default audio IDs are zero.
10. **Optional purchases/release:** Keep paid IDs zero or configure experience-owned fixed coin product/cosmetic pass. Owner-authorized live price/ownership/receipt/failure/retry tests remain. No public Roblox publication, assets uploaded to an account, Robux spent or live purchases occurred.

## Current official documentation consulted

Official Roblox `creator-docs` was fetched on 2026-10-13 at commit `784c5e217446c65958d5d84f5c5f1d127951a8d7`. The implementation reviewed these actual pages/API references rather than relying only on memory:

- [ParticleEmitter](https://create.roblox.com/docs/reference/engine/classes/ParticleEmitter): bounded emission/lifetime, texture, direction/spread, size and Squash. Positive Squash makes vertically stretched rainfall; snow keeps square flakes. Gameplay does not rely on particles.
- [AssetService/CreateMeshPartAsync](https://create.roblox.com/docs/reference/engine/classes/AssetService): supported mesh content/import workflow; no fake editable MeshId or unauthenticated mesh upload is attempted.
- [ViewportFrame](https://create.roblox.com/docs/ui/viewport-frames): separate camera/world geometry for native storm-card previews.
- [GuiButton](https://create.roblox.com/docs/reference/engine/classes/GuiButton): Activated supports mouse/touch/controller; event wiring belongs on the client.
- [ProximityPrompt](https://create.roblox.com/docs/reference/engine/classes/ProximityPrompt), [client-server boundary](https://create.roblox.com/docs/scripting/security/client-server-boundary): UI-opening prompts still validate server distance, as client-visible interaction settings are not authoritative.
- [UIStroke](https://create.roblox.com/docs/reference/engine/classes/UIStroke), [TweenService](https://create.roblox.com/docs/reference/engine/classes/TweenService): native borders and restrained local animations.
- [Player data/purchasing](https://create.roblox.com/docs/cloud-services/data-stores/player-data-purchasing), [DataStore best practices](https://create.roblox.com/docs/cloud-services/data-stores/best-practices): local profiles, periodic/final saves, session exclusion, UpdateAsync and durable receipt records.
- [Developer products](https://create.roblox.com/docs/production/monetization/developer-products), [passes](https://create.roblox.com/docs/production/monetization/passes): current client prices, authoritative ownership and ProcessReceipt fulfillment.
- [Audio assets](https://create.roblox.com/docs/audio/assets): original rights, formats/limits, assigned IDs, moderation and experience permission.
- [Publishing](https://create.roblox.com/docs/production/publishing/publish-games-and-places): private/public/limited access and audience-dependent eligibility/compliance. Owner eligibility and fees were not changed or attempted.

Original geometry/UI art/audio are supplied without Toolbox loaders or paid random rewards. Account-specific moderation, asset availability, sound playback and release compliance remain owner responsibilities and unverified capabilities, not completed setup claims.
