"""Validate current results and assets, create the complete ZIP, verify every member."""
from pathlib import Path
import hashlib, json, struct, subprocess, sys, tempfile, wave, zipfile
ROOT=Path.cwd()
DIST=ROOT/'dist'
ZIP=DIST/'Grow_a_Storm_Complete_Package.zip'
results=[]
def record(name):
    results.append({'Name':name,'Status':'passed'})
    print('PASS',name)
def digest(blob): return hashlib.sha256(blob).hexdigest()
reports={}
for name,count in [('rules',29),('science',34),('balance',5),('runtime',32),('exports',12)]:
    path=ROOT/'tests'/f'{name}-results.json'
    report=json.loads(path.read_text())
    assert report['Passed']==count and len(report['Tests'])==count,(name,'incomplete suite')
    assert all(t['Status']=='passed' for t in report['Tests'])
    # Reject stale output written before any tested script/tool.
    latest=max(p.stat().st_mtime for p in (ROOT/'src').glob('*.luau'))
    assert path.stat().st_mtime>=latest,(name,'stale source')
    assert path.stat().st_mtime>=(ROOT/('tools/balance.luau' if name=='balance' else f'tests/{name}.luau')).stat().st_mtime,(name,'stale harness')
    assert path.stat().st_mtime>=(DIST/'Grow_a_Storm.rbxl').stat().st_mtime,(name,'stale build')
    reports[name]=report
record('All 112 Luau checks completed with fresh result files')
for name,seconds in [('Music',32),('Rain',8),('Pickup',.23),('Evolve',1.5),('Click',.09),('Thunder',2.5)]:
    path=ROOT/'audio'/f'{name}.wav'
    with wave.open(str(path),'rb') as w:
        assert w.getnchannels()==1 and w.getsampwidth()==2 and w.getframerate()==24000 and w.getcomptype()=='NONE'
        assert abs(w.getnframes()/24000-seconds)<1/24000
        frames=w.readframes(w.getnframes())
        samples=struct.unpack('<'+'h'*(len(frames)//2),frames)
        assert max(abs(x) for x in samples)>100 and max(abs(x) for x in samples)<32767
        assert len(path.read_bytes())<20_000_000 and seconds<420
record('Six original non-silent mono PCM WAVs satisfy format and size limits')
with tempfile.TemporaryDirectory() as tmp:
    (Path(tmp)/'audio').mkdir()
    subprocess.run([sys.executable,str(ROOT/'tools'/'audio.py')],cwd=tmp,check=True,capture_output=True)
    for f in (ROOT/'audio').glob('*.wav'):
        assert digest(f.read_bytes())==digest((Path(tmp)/'audio'/f.name).read_bytes())
record('Original audio regeneration is byte-for-byte reproducible')
required=['README.md','TESTING_AND_RELEASE.md','SETUP_ASSET_IDS.luau','LICENSE',
          'docs/REQUIREMENTS.md','docs/Grow_a_Storm_Codex_Metaprompt.md',
          'tools/build.luau','tools/world.luau','tools/audio.py','tools/setup.sh','tools/check.sh','tools/package.py',
          'SETUP_MESH_LIBRARY.luau','docs/GROW_A_STORM_2_0_SPEC.md','docs/2_0_CHECKLIST.md','docs/2_0_ARCHITECTURE.md','docs/BALANCE.json','docs/Blender_Cloud_Gallery.png']
assert all((ROOT/f).is_file() for f in required)
assert len(list((ROOT/'models').glob('*.rbxm')))==64
assert len(list((ROOT/'src').glob('*.luau')))==14
assert all((DIST/f'Grow_a_Storm.{ext}').stat().st_size>10000 for ext in ['rbxl','rbxlx'])
assert 'C.AuroraPass=0' in (ROOT/'src'/'StormConfig.luau').read_text()
assert 'C.DropsProduct=0' in (ROOT/'src'/'StormConfig.luau').read_text()
record('Required places, models, source, utilities, spec and release documentation present')
# Inspect actual mesh files, including topology and every material dependency.
import math
manifest=json.loads((ROOT/'meshes/MESH_MANIFEST.json').read_text())
designs=json.loads((ROOT/'meshes/designs.json').read_text())
assert len(designs)==36 and len(manifest)==36 and len({d['Name'] for d in designs})==36
mesh_hashes=set()
for design in designs:
    name=design['Name']+'.obj'; path=ROOT/'meshes'/name
    lines=path.read_text().splitlines()
    vertices=[line.split()[1:] for line in lines if line.startswith('v ')]
    faces=[line.split()[1:] for line in lines if line.startswith('f ')]
    assert len(vertices)==manifest[name]['Vertices'] and len(faces)==manifest[name]['Faces']
    assert len(vertices)>100 and len(faces)>100
    assert all(len(v)==3 and all(math.isfinite(float(x)) for x in v) for v in vertices)
    for face in faces:
        assert len(face)>=3
        for reference in face:
            index=int(reference.split('/')[0]); assert index!=0 and -len(vertices)<=index<=len(vertices)
    deps=[line.split(maxsplit=1)[1] for line in lines if line.startswith('mtllib ')]
    assert deps and all((ROOT/'meshes'/dep).is_file() for dep in deps)
    mesh_hashes.add(digest(path.read_bytes()))
assert len(mesh_hashes)==36
blend=(ROOT/'meshes/Grow_a_Storm_Original_Clouds.blend').read_bytes()
assert blend[:7]==b'BLENDER' and len(blend)>1_000_000
assert (ROOT/'docs/Blender_Cloud_Gallery.png').read_bytes()[:8]==b'\x89PNG\r\n\x1a\n'
record('All 36 original OBJ meshes have distinct geometry, valid finite topology/materials, Blender source and rendered gallery')
balance=json.loads((ROOT/'docs/BALANCE.json').read_text())
assert len(balance['StormRates'])==12 and len(balance['EquipmentLevelCosts'])==12
assert all(0<t<=600 for t in balance['MilestonesSeconds'].values())
assert balance['TenMinuteEnding']['Bays']>=2 and balance['MutationCap']==1.5
record('Actual 600-second rain simulation, twelve storm rates and all device/research cost calculations included')

def inputs():
    mapping={f.name:f for f in DIST.glob('Grow_a_Storm.rbxl*')}
    for name in ['README.md','TESTING_AND_RELEASE.md','SETUP_ASSET_IDS.luau','SETUP_MESH_LIBRARY.luau','LICENSE','.gitignore']:
        mapping[name]=ROOT/name
    for folder in ['src','tools','tests','models','audio','docs','meshes']:
        for p in (ROOT/folder).rglob('*'):
            if p.is_file() and '__pycache__' not in p.parts and p.name!='validation.log':
                mapping[p.relative_to(ROOT).as_posix()]=p
    return mapping
def write_zip():
    mapping=inputs()
    inventory={name:digest(path.read_bytes()) for name,path in sorted(mapping.items())}
    with zipfile.ZipFile(ZIP,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,path in sorted(mapping.items()): z.writestr(name,path.read_bytes())
        z.writestr('SHA256SUMS.json',json.dumps(inventory,indent=2,sort_keys=True)+'\n')
    return mapping
def verify_zip(mapping):
    with zipfile.ZipFile(ZIP) as z:
        assert z.testzip() is None
        assert set(z.namelist())==set(mapping)|{'SHA256SUMS.json'}
        inventory=json.loads(z.read('SHA256SUMS.json'))
        for name,path in mapping.items():
            assert not name.startswith('/') and '..' not in Path(name).parts
            assert z.read(name)==path.read_bytes() and digest(z.read(name))==inventory[name]
        assert z.read('Grow_a_Storm.rbxl')==(DIST/'Grow_a_Storm.rbxl').read_bytes()
        assert z.read('Grow_a_Storm.rbxlx')==(DIST/'Grow_a_Storm.rbxlx').read_bytes()
        for f in (ROOT/'src').glob('*.luau'): assert z.read('src/'+f.name)==f.read_bytes()
        for f in (ROOT/'audio').glob('*.wav'): assert z.read('audio/'+f.name)==f.read_bytes()
# First verify the actual archive. Record its check only after verification succeeds.
verify_zip(write_zip())
record('ZIP CRCs, complete membership, per-file hashes and nested deliverable identities verified')
assert len(results)==7
(ROOT/'tests'/'artifact-results.json').write_text(json.dumps({'Kind':'Real filesystem/WAV/ZIP checks','Passed':7,'Tests':results},indent=2)+'\n')
summary="""# Final executed validation

**119 checks passed**: 29 retained rule tests, 34 cultivation/science tests,
32 embedded-server/client tests, 12 DOM/export/helper checks, five balance/pool
checks, and seven artifact/package checks. All 14 production scripts and both
editor helpers compile with the Luau compiler in Lune 0.11.0. Both places
deserialize with Roblox DOM; Workspace contains 2,116 physical parts, and the
complete DataModel contains 3,814 including stored model libraries. Embedded
sources match editable sources. Six original WAVs, 64 native model exports,
36 original OBJ/MTL assets and the editable Blender project are included.

The deterministic actual-rain simulation reaches Magnet, another core, a
condenser, research, a second cloud and maturity within ten minutes, without
gifts, global events or co-op. It is not a human usability study.

The server/client checks execute actual final source with mocked services and
DOM instances. They are not Roblox Studio Play tests. Actual engine play,
multiplayer replication, real UI/device/controller rendering, mobile FPS,
published saves, mesh/audio uploads and live purchases remain unrun. See
TESTING_AND_RELEASE.md. The native place works without importing external
meshes; the Blender mesh assets require owner import to become MeshParts.

Individual checks are listed in six JSON result files beside this report.
No public Roblox publication, account uploads, spending or live purchases occurred.
"""
(ROOT/'tests'/'RESULTS.md').write_text(summary)
# Include final reports, then verify the final archive again (not just staging).
verify_zip(write_zip())
(DIST/'Grow_a_Storm_Complete_Package.zip.sha256').write_text(digest(ZIP.read_bytes())+'  '+ZIP.name+'\n')
print(f'FINAL PACKAGE VERIFIED: {ZIP.name} ({ZIP.stat().st_size:,} bytes); 119 checks passed')
