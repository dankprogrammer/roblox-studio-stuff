"""Offline visualization of the actual native DOM geometry, not Studio rendering."""
from pathlib import Path
import os,json,math
os.environ.setdefault('MPLCONFIGDIR','/tmp/grow-storm-matplotlib')
import numpy as np
items=json.loads(Path('docs/final_geometry.json').read_text())
faces=[];colors=[]
def mesh(item):
    shape=item['Shape']
    if shape=='Block':
        v=np.array([[x,y,z] for x in [-.5,.5] for y in [-.5,.5] for z in [-.5,.5]])
        idx=[[0,1,3,2],[4,6,7,5],[0,4,5,1],[2,3,7,6],[0,2,6,4],[1,5,7,3]]
    elif shape=='Cylinder':
        # Roblox cylinder's longitudinal axis is X.
        seg=20;v=np.array([[x,math.cos(i*2*math.pi/seg)*.5,math.sin(i*2*math.pi/seg)*.5] for x in [-.5,.5] for i in range(seg)])
        idx=[list(range(seg))[::-1],list(range(seg,seg*2))]+[[i,(i+1)%seg,(i+1)%seg+seg,i+seg] for i in range(seg)]
    else:
        seg=10;rings=6
        v=np.array([[math.sin(a)*math.cos(b)*.5,math.cos(a)*.5,math.sin(a)*math.sin(b)*.5] for a in np.linspace(0,math.pi,rings) for b in np.linspace(0,2*math.pi,seg,endpoint=False)])
        idx=[[r*seg+i,r*seg+(i+1)%seg,(r+1)*seg+(i+1)%seg,(r+1)*seg+i] for r in range(rings-1) for i in range(seg)]
    basis=np.array(item['Basis']).T
    world=(v*np.array(item['Size']))@basis.T+np.array(item['Position'])
    # Plot coordinates: X, Z, Y.
    world=world[:,[0,2,1]]
    return [[world[j] for j in f] for f in idx]
for item in items:
    x,y,z=item['Position']
    if abs(x)>165 or abs(z)>165 or y<-8 or y>45: continue
    parts=mesh(item)
    faces.extend(parts)
    for face in parts:
        v=np.array(face)
        normal=np.cross(v[1]-v[0],v[2]-v[0]);norm=np.linalg.norm(normal)
        light=.83+.17*abs(normal[2]/norm) if norm>1e-8 else .85
        colors.append(tuple(min(1,c*light) for c in item['Color']))
# A CPU z-buffer avoids painter-order errors from large native ground faces.
from PIL import Image,ImageDraw,ImageFont
width,height=1500,1100
buffer=np.empty((height,width,3),dtype=np.uint8);buffer[:]=[231,245,252]
depth=np.full((height,width),np.inf)
look=np.array([-270,320,-350.0]);look/=np.linalg.norm(look)
right=np.cross(look,np.array([0,0,1.]));right/=np.linalg.norm(right)
up=np.cross(right,look)
for face,color in zip(faces,colors):
    p=np.array(face)
    xy=np.column_stack((p@right*3.05+width*.5,-p@up*3.05+height*.55))
    dz=p@look
    for i in range(1,len(p)-1):
        ids=[0,i,i+1];v=xy[ids];z=dz[ids]
        x0=max(0,int(np.floor(v[:,0].min())));x1=min(width-1,int(np.ceil(v[:,0].max())))
        y0=max(0,int(np.floor(v[:,1].min())));y1=min(height-1,int(np.ceil(v[:,1].max())))
        if x1<x0 or y1<y0: continue
        denominator=(v[1,1]-v[2,1])*(v[0,0]-v[2,0])+(v[2,0]-v[1,0])*(v[0,1]-v[2,1])
        if abs(denominator)<1e-7: continue
        xx,yy=np.meshgrid(np.arange(x0,x1+1)+.5,np.arange(y0,y1+1)+.5)
        aa=((v[1,1]-v[2,1])*(xx-v[2,0])+(v[2,0]-v[1,0])*(yy-v[2,1]))/denominator
        bb=((v[2,1]-v[0,1])*(xx-v[2,0])+(v[0,0]-v[2,0])*(yy-v[2,1]))/denominator
        cc=1-aa-bb; zz=aa*z[0]+bb*z[1]+cc*z[2]
        target=depth[y0:y1+1,x0:x1+1]
        mask=(aa>=-1e-6)&(bb>=-1e-6)&(cc>=-1e-6)&(zz<target)
        target[mask]=zz[mask]
        buffer[y0:y1+1,x0:x1+1][mask]=np.array(color)*255
image=Image.fromarray(buffer)
draw=ImageDraw.Draw(image)
font='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
try: title=ImageFont.truetype(font,32);body=ImageFont.truetype(font,16)
except OSError: title=ImageFont.load_default();body=title
draw.text((60,40),'GROW A STORM',fill='#274b5e',font=title)
draw.text((60,88),'Actual exported geometry: central plaza + eight cloud gardens',fill='#5b7d8b',font=body)
draw.text((60,height-50),'Offline CPU geometry render. Not Roblox Studio lighting, UI, particles or a playtest.',fill='#5b7d8b',font=body)
image.save('docs/Map_Offline_Preview.png')
print('Saved z-buffered actual-DOM geometry visualization (not a Studio screenshot)')
