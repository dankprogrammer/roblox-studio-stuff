#!/usr/bin/env bash
set -euo pipefail
# All result files are deleted first. Exit status alone cannot hide incomplete runs.
rm -f tests/rules-results.json tests/runtime-results.json tests/exports-results.json tests/artifact-results.json
python3 tools/audio.py
.tools/lune run tools/build.luau
.tools/lune run tools/geometry_preview.luau
.tools/lune run tests/rules.luau
.tools/lune run tests/runtime.luau
.tools/lune run tests/exports.luau
python3 tools/package.py
