import bpy
from pathlib import Path
from mathutils import Vector
root=Path.cwd();bpy.ops.wm.open_mainfile(filepath=str(root/'meshes/Grow_a_Storm_Original_Clouds.blend'))
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=24;scene.cycles.use_denoising=False;scene.render.resolution_percentage=70
scene.view_settings.view_transform='Standard';scene.view_settings.look='Medium High Contrast' if 'Medium High Contrast' in [x.name for x in scene.view_settings.bl_rna.properties['look'].enum_items] else 'None'
scene.world.node_tree.nodes['Background'].inputs[1].default_value=.45
for o in scene.objects:
 if o.type=='LIGHT': o.data.energy*=12
scene.camera.data.ortho_scale=166
scene.render.film_transparent=True;scene.render.filepath=str(root/'docs/Blender_Cloud_Gallery.png');bpy.ops.render.render(write_still=True)
print('Reviewed framing/lighting; rendered full original 36-stage gallery')
