"""Original procedural audio; no samples, external assets, or music dependencies."""
import math, random, struct, wave
from pathlib import Path
RATE=24000
rng=random.Random(729)
def save(name,seconds,fn):
    path=Path('audio')/f'{name}.wav'
    with wave.open(str(path),'wb') as out:
        out.setnchannels(1); out.setsampwidth(2); out.setframerate(RATE)
        values=[]
        for i in range(round(seconds*RATE)):
            t=i/RATE
            value=max(-.92,min(.92,fn(t,seconds)))
            values.append(struct.pack('<h',round(value*32767)))
        out.writeframes(b''.join(values))
def tone(t,f): return math.sin(2*math.pi*f*t)
chords=[(261.6256,329.6276,391.9954),(220,261.6256,329.6276),(174.6141,220,261.6256),(195.9977,246.9417,293.6648)]
def music(t,d):
    chord=chords[int(t//8)%4]
    # Rounded pads fade through chord boundaries. Seam has zero amplitude.
    phase=(t%8)/8
    env=math.sin(math.pi*phase)**2
    pad=sum(tone(t,f)+.24*tone(t,f*2) for f in chord)*.055*env
    beat=t%1
    bell=tone(beat,chord[int(t)%3]*2)*math.exp(-beat*7)*.075*math.sin(math.pi*min(1,beat/.012))
    return (pad+bell)*min(1,t/.05,(d-t)/.05)
def rain(t,d):
    return rng.uniform(-1,1)*.13*min(1,t/.1,(d-t)/.1)+tone(t,85)*.008
save('Music',32,music)
save('Rain',8,rain)
save('Pickup',.23,lambda t,d:(tone(t,880)+.35*tone(t,1320))*.22*math.exp(-t*15)*min(1,t/.008))
save('Evolve',1.5,lambda t,d:sum(tone(t,f) for f in (523.25,659.25,783.99))* .11*math.sin(math.pi*t/d)**2)
save('Click',.09,lambda t,d:tone(t,420+900*t)*.15*math.exp(-t*45)*min(1,t/.003))
save('Thunder',2.5,lambda t,d:(rng.uniform(-1,1)*.28+tone(t,45)*.15+tone(t,63)*.07)*math.exp(-t*2)*min(1,t/.025))
print('Generated six original mono PCM WAVs at 24 kHz')
