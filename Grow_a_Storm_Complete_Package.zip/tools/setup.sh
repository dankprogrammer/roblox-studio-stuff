#!/usr/bin/env bash
set -euo pipefail
# Run from the checkout root. No sudo, source edits, or secrets required.
version=0.11.0
archive_sha=5a0ea32c3e13e5e3b1dc415c2056bcfe44258b3a811dcd473c50e3b437d10f72
mkdir -p .tools
if [[ ! -f .tools/lune.zip ]]; then
  curl --fail --location --proto '=https' --tlsv1.2 \
    "https://github.com/lune-org/lune/releases/download/v${version}/lune-${version}-linux-x86_64.zip" \
    --output .tools/lune.zip
fi
printf '%s  %s\n' "$archive_sha" '.tools/lune.zip' | sha256sum --check --status
unzip -o .tools/lune.zip -d .tools >/dev/null
chmod +x .tools/lune
.tools/lune --version
