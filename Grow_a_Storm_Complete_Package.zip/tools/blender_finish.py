import bpy,json
from pathlib import Path
root=Path.cwd()
bpy.ops.wm.open_mainfile(filepath=str(root/'meshes/Grow_a_Storm_Original_Clouds.blend'))
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=12;scene.cycles.use_denoising=False
scene.render.resolution_percentage=60;scene.render.filepath=str(root/'docs/Blender_Cloud_Gallery.png');bpy.ops.render.render(write_still=True)
manifest={}
for f in (root/'meshes').glob('*.obj'):
 lines=f.read_text().splitlines();manifest[f.name]={'Vertices':sum(x.startswith('v ') for x in lines),'Faces':sum(x.startswith('f ') for x in lines)}
assert len(manifest)==36 and all(v['Vertices']>100 and v['Faces']>100 for v in manifest.values())
(root/'meshes/MESH_MANIFEST.json').write_text(json.dumps(manifest,indent=2))
print('Inspected 36 original voxel-fused OBJ meshes; CPU gallery completed')
