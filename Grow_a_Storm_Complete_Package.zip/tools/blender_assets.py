"""Run with Blender -b --python tools/blender_assets.py; original sculpted models."""
import bpy, json, math, os
from pathlib import Path
from mathutils import Vector
ROOT=Path.cwd();items=json.loads((ROOT/'meshes/designs.json').read_text())
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
materials={}
def mat(rgb,glow=False):
    key=tuple(round(x) for x in rgb)+(int(glow),)
    if key not in materials:
        m=bpy.data.materials.new('Storm_'+str(key));m.diffuse_color=tuple(x/255 for x in rgb)+(1,);m.use_nodes=True
        shader=m.node_tree.nodes.get('Principled BSDF');shader.inputs['Base Color'].default_value=m.diffuse_color;shader.inputs['Roughness'].default_value=.65
        if glow: shader.inputs['Emission Color'].default_value=m.diffuse_color;shader.inputs['Emission Strength'].default_value=.18
        materials[key]=m
    return materials[key]
collections=[]
for index,design in enumerate(items):
    collection=bpy.data.collections.new(design['Name']);bpy.context.scene.collection.children.link(collection);objects=[];volumes=[]
    for p in design['Parts']:
        if p['Shape']=='Ball': bpy.ops.mesh.primitive_uv_sphere_add(segments=16,ring_count=8,radius=.5)
        elif p['Shape']=='Cylinder': bpy.ops.mesh.primitive_cylinder_add(vertices=16,radius=.5,depth=1)
        else: bpy.ops.mesh.primitive_cube_add(size=1)
        o=bpy.context.object;o.name=p['Name'];o.location=(p['Pos'][0],-p['Pos'][2],p['Pos'][1]);o.scale=(p['Size'][0],p['Size'][2],p['Size'][1]);o.rotation_euler=(p['Rot'][0],-p['Rot'][2],p['Rot'][1])
        o.data.materials.append(mat(p['Color'],p['Material']=='Neon'))
        for poly in o.data.polygons: poly.use_smooth=p['Shape']=='Ball'
        for old in list(o.users_collection): old.objects.unlink(o)
        collection.objects.link(o);objects.append(o)
        if p['Name'] in ('SculptedVolume','Undercurl','CloudWisp'): volumes.append(o)
    # Actually fuse the cloud masses into a continuous original organic mesh.
    bpy.ops.object.select_all(action='DESELECT')
    for o in volumes: o.select_set(True)
    bpy.context.view_layer.objects.active=volumes[0];bpy.ops.object.join();body=volumes[0]
    bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
    modifier=body.modifiers.new('Sculpted voxel union','REMESH');modifier.mode='VOXEL';modifier.voxel_size=.32;modifier.use_smooth_shade=True
    bpy.ops.object.modifier_apply(modifier=modifier.name)
    smooth=body.modifiers.new('Organic smoothing','SMOOTH');smooth.factor=.45;smooth.iterations=3;bpy.ops.object.modifier_apply(modifier=smooth.name)
    objects=list(collection.objects)
    bpy.ops.object.select_all(action='DESELECT')
    for o in objects: o.select_set(True)
    bpy.context.view_layer.objects.active=body
    bpy.ops.wm.obj_export(filepath=str(ROOT/'meshes'/f'{design["Name"]}.obj'),export_selected_objects=True,export_materials=True)
    # Assemble an inspectable gallery in the editable source blend.
    shift=Vector(((index//3)%6*21,(index//18)*38+(2-design['Stage'])*12,0))
    for o in objects: o.location+=shift
    collections.append(collection)
# Warm original lighting and an isometric CPU render, not a Roblox screenshot.
scene=bpy.context.scene;scene.render.engine='BLENDER_EEVEE_NEXT';scene.render.resolution_x=2200;scene.render.resolution_y=1300;scene.render.resolution_percentage=100
scene.world.use_nodes=True;scene.world.node_tree.nodes['Background'].inputs[0].default_value=(.72,.84,.94,1);scene.world.node_tree.nodes['Background'].inputs[1].default_value=.6
bpy.ops.object.light_add(type='AREA',location=(30,-20,65));bpy.context.object.data.energy=2600;bpy.context.object.data.shape='DISK';bpy.context.object.data.size=65
bpy.ops.object.light_add(type='AREA',location=(100,50,40));bpy.context.object.data.energy=1800;bpy.context.object.data.size=50
bpy.ops.object.camera_add(location=(130,-140,130));camera=bpy.context.object;target=Vector((52,26,1));camera.rotation_euler=(target-camera.location).to_track_quat('-Z','Y').to_euler();camera.data.type='ORTHO';camera.data.ortho_scale=145;scene.camera=camera
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'meshes'/'Grow_a_Storm_Original_Clouds.blend'))
# CPU Cycles works in this headless cloud machine without a GPU.
scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=12;scene.cycles.use_denoising=False;scene.render.resolution_percentage=60
scene.render.filepath=str(ROOT/'docs'/'Blender_Cloud_Gallery.png');bpy.ops.render.render(write_still=True)
manifest={}
for f in (ROOT/'meshes').glob('*.obj'):
    txt=f.read_text();manifest[f.name]={'Vertices':sum(1 for x in txt.splitlines() if x.startswith('v ')),'Faces':sum(1 for x in txt.splitlines() if x.startswith('f '))}
assert len(manifest)==36 and all(v['Vertices']>100 and v['Faces']>100 for v in manifest.values())
(ROOT/'meshes'/'MESH_MANIFEST.json').write_text(json.dumps(manifest,indent=2))
print('Created and inspected 36 original voxel-fused OBJ meshes + editable Blender source + CPU gallery')
