# Current 2.0 requirements mapping

The controlling uploaded request is GROW_A_STORM_2_0_SPEC.md. Prior specs remain historical.

| Requested area | Implemented artifact/system | Validation/remaining review |
|---|---|---|
| Audit/retain/backup existing game | PRE_2_0_AUDIT.md; original/pre-2.0 native snapshots; existing rain/profile/plot/link modules | Baseline and regression suites; Studio engine review pending |
| A/B premium UI and expandable HUD/screens | StormUI, StormClient; 3D market/encyclopedia previews, three tabs, three default controls | Actual client/service doubles and five bounds; actual Studio screenshot/device review pending |
| C twelve unique storms × three stages | StormDefinitions, StormModelFactory; 36 native stage exports; actual Blender/OBJ/MTL source | Geometry tests, mesh topology/material validation, reviewed Blender render; MeshParts require owner import |
| D sanctuary/advanced plots | tools/world/sanctuary, embedded map; six stations/eight gardens; terraces/layouts/devices | DOM geometry, safe lanes, server actions/release; engine visual/performance review pending |
| E core/inventory/growth/resources | StormScience/StormEconomy/StormServer | Twelve acquisition paths, copying limits, growth/reset/save, real-rain ten-minute simulation |
| F mutation/engineering | Ten deterministic recipes, journal/variants, compatibility/two-cap; four climate controls | All ten real recipes, tuning ranges, no failed-spend grants, actual remote integration |
| G machinery/research/balance | Twelve devices × three levels; five branches × three levels; BALANCE.json | Actual effects and finite costs; human balance/playstyle review pending |
| H social/quests/events/prestige | Visits/showcases/public discoveries, community events/sprints/chasing, eleven goals/daily quests, preserved prestige | Source and integration tests; real multiplayer/replication pending; optional trading omitted |
| I testing/performance/security | Six result JSONs/RESULTS.md; bounded rain, local animation, server-stored templates, mutex/leases/receipt safeguards | 119 actual offline checks; actual Studio/mobile/save/account tests unrun |

Audio code and six original WAVs are delivered but default Roblox audio IDs remain zero. Owner uploads/moderation/permissions are needed for playback. Optional pass/product setup remains separate, and no live purchases or Roblox publishing were attempted.
