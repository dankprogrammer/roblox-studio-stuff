# Grow a Storm — implemented overhaul

This updates the existing native place and source. The builder deserializes the backed-up existing place, preserves unrelated services/instances, replaces the known map and production scripts, then exports both place formats. It does not start from an empty DataModel. The uploaded `UPDATED_OVERHAUL_SPEC.md` is the current specification; the older metaprompt is retained only as project history.

A verified checkpoint exists at `/workspace/backups/Grow_a_Storm_before_overhaul_2026-10-13.tar.gz`, covering source, artifacts and Git metadata. `docs/Grow_a_Storm_Before_Overhaul.rbxl` is the original place for immediate rollback. The old save name `GrowAStorm_v1` and decimal user ID keys stay unchanged.

## Audit and resolved problems

- The old game had no owned plots or growing areas. All 180 collectible drops were shared island rain. Character-following clouds did not produce their own resources. Eight owned gardens now assign/release automatically; each active cloud has its own owner-validated, bounded eight-drop pool.
- The reported Studio falling-rain failure could not be reproduced with the original offline harness. No Studio Output or live connection was available. The new implementation adds independent startup, protected heartbeat stages, health diagnostics, rate-limited error logging and recovery for deleted, unanchored or malformed pool objects. It does not rely on particle collision, gravity or Touched for grants.
- Player/presentation errors could interrupt the old rain heartbeat before its motion step. Player sampling and rain processing now have separate protected boundaries. DataStore initialization/loading cannot prevent global rain from starting.
- The old HUD had no storm collection/discovery UI or persistent settings. It has been replaced by compact resource chips, readable growth/event/objective prompts, outlined pastel controls, upgrade cards and an eight-entry collection catalog.
- The old world had no true central multiplayer garden layout, ownership signage, environmental interactions or visible cloud bays. The hub is now an authored grass plaza with radial paths and eight gardens, preserving the six weather destination identities while moving outposts outward to prevent overlap.
- Dynamic clouds were replicated every server heartbeat. Clouds now remain over their gardens; decorative bobbing, growth/hover tweens and windmill motion run locally. Collectible motion/rewards remain authoritative on the server.
- Setting restart/duplicate-client, malformed pooled-object and bay ownership cases were fixed during this implementation and are covered by final regression tests. These implementation fixes are distinct from independently established old-game defects.

## Gameplay systems

Rain immediately creates reachable landed pickups plus visibly falling pickups. A starter cloud has eight slots; the maximum eight-player/three-bay configuration is 192 plot drops plus 180 shared weather-field drops: **372 maximum pooled gameplay drops**, with cleanup on leave/bay reset. Gold slots are free and deterministic, not paid random rewards.

Collecting rainfall grants coins (wallet Drops), earned storm energy (Total) and lifetime water (Water). Spending coins never reduces energy. Quest, gift and fixed paid-wallet rewards never masquerade as collected water or earned energy. The first objective is five water; Magnet costs 35 coins; 60 energy evolves the cloud and discovers Rain Cloud. Home/respawn returns to the owned garden; Plaza and Travel remain available.

Eight free storm discoveries have distinct colors/effects and production multipliers: Sunny Drizzle, Rain Cloud, Thundercloud, Blizzard, Electric Storm, Aurora Storm, Solar Tempest and Cosmic Storm. Discoveries and best energy survive Forecast Ascension. Select a cloud bay and equip a discovered storm; equipment changes actual producing clouds. Six cloud growth levels add geometry, faces, rain charms, lightning, orbit gems/ice crystals and a final crown. The paid Aurora color/halo is separate from the free Aurora Storm discovery.

Retained Magnet, Rain Power, Boots and Gold Amplifier upgrades are joined by Rain Tempo (falling speed/recycle cadence) and Cloud Bays (one extra producing cloud per level, gated at 220/600 best energy). Existing quests/gift, 3,000-energy Forecast Ascension, permanent stars and explicit consenting Storm Link remain.

Heavy Rain, Thunderstorm, Rainbow Weather and Blizzard rotate with announcements, countdowns, production bonuses, particle variations and gentle atmosphere tint changes. Personal plots benefit regardless of the featured destination; themed shared-field bonuses still respect island tier gates. Weather never removes ordinary production.

Settings for music, sound effects, reduced motion and low effects are saved. Reduced motion disables world bobbing/spinning/UI tweening; low effects cuts decorative emission and animation cadence. Original WAVs and playback/control code are retained; owner uploads/permissions and real IDs are still required before Roblox audio can play.

## Environment and interface

The central plaza includes a welcoming cloud/lightning fountain monument, radial paths, Rain Workshop, Storm Collection station, Forecast Ascension area, pond/stream, rocks, flowers, canopy trees, weather observation instruments and a windmill. Shop/index/ascension ProximityPrompts use server distance validation and open genuine UI screens. Gardens have numbered ownership metadata, colored borders, clean collection floors, three grow pads, planting space and readable progress boards. Trees/props remain outside production lanes and arrivals. Lighting uses clear daylight, a native sky, restrained Atmosphere/Bloom and ColorCorrection.

The rebuilt UI uses cream/pastel panels, UIStroke, gradients, native icons, consistent rounding/spacing, compact money/water/level chips, an energy meter, weather status and a contextual objective button. The six-button navigation bar keeps ≥44px hit areas at tested dimensions. Panels scroll instead of obscuring the entire display. Upgrade cards show cost, level, effects, affordability, maximum and locked states. Collection cards include real ViewportFrame previews, rarity, production, discovery and equipment state. There are no fake action controls.

Controller selected objects stay stable during state updates; close/backdrop/Back restore navigation. Notices distinguish pickups, purchases, evolution/discoveries, insufficient currency and events. Important notices are protected from immediate pickup spam. Reinitialization replaces one GUI and cleans old remote/input handlers and sounds.

## Runtime structure

| Location | Script/module | Role |
|---|---|---|
| ReplicatedStorage | StormConfig | Economy, catalog, plot geometry, weather and asset configuration |
| ReplicatedStorage | StormEconomy | Normalization/migration, rewards, purchases, tutorial, discovery/equipment/settings |
| ReplicatedStorage | StormRain | Shared and owner-specific pooling, falling motion, collection gates and lifecycle |
| ReplicatedStorage | StormProfiles | Session lease, save/retry/receipt transactions and reconciliation |
| ReplicatedStorage | StormLink | Two-party consent, distance, readiness/boost/cooldown |
| ReplicatedStorage | StormPlots | Eight-plot assignment, ownership and release |
| ServerScriptService | StormServer | Authoritative game wiring, clouds, arrivals, events, prompts, saves and receipts |
| StarterPlayerScripts | StormClient | Complete HUD/screens, shop/catalog/settings, input, notices and sound |
| StarterPlayerScripts | StormWorld | Client-only cloud/scene animation, particles, quality and weather tint |

StormAction/StormState/StormNotice are the only game remotes. Client requests never supply resource grants or trusted costs/levels. Profiles retain lease checks, safe live-load rejection, explicitly temporary Studio fallback, three retries, approximately 70-second autosaves and bounded shutdown saves. Purchase rewards and receipt markers are committed together before acknowledgment; mutations pause during receipt work, including uncertain-result recovery. Settings, storm history/equipment, lifetime water and best energy migrate from legacy profiles without deleting recognized progress.

## Tests and limits

The final executable results in `tests/` record the actual final files. The suite exercises existing production rules, embedded server/client code with Roblox DOM/service doubles, and real exported geometry/source/model inspection. It includes starter collection/upgrades, independent owner-only rain, eight simultaneous profiles/overflow, equipment/bays, respawn, events, save/rejoin, receipt retry/failure, settings/reinitialization, world effects and calculated layout bounds for five display sizes.

`Map_Offline_Preview.png` renders the actual exported native geometry using a CPU z-buffer. It is a composition aid, **not a Roblox Studio screenshot**; it does not reproduce engine lighting, UI, particles or live-player clouds.

Roblox Studio and account capabilities are unavailable. Engine Play, real two-client replication, actual glyph clipping, controller/device navigation, mobile performance, published persistence, audio permissions/playback and live purchase behavior remain **unrun**. The game is implemented and offline-validated; it is not certified release-ready or proven comparable to a commercial game's production quality. See TESTING_AND_RELEASE.md for exact owner checks. No Roblox experience was published and no Robux/live purchase was made.
