You are my Roblox developer. Rebuild or improve my complete Roblox game, “Grow a Storm!”, using the project history and specification below. Do the actual implementation and deliver playable Roblox Studio place files, models, assets, source and tests. Do not stop at a plan, code snippets, or an installation tutorial.

## Goal and project history

I originally asked for a potential hit Roblox game inspired by the community appeal of games such as Steal an Egg and +1 Keyboard Escape. We chose an original weather-growth simulator called Grow a Storm. The aim is an immediately understandable loop, satisfying progression, collectible rewards, social play and dramatic visual upgrades. Do not promise commercial success or copy another game's branding/assets.

I then requested the complete game, including models, following current Roblox Creator Hub requirements. I asked to make everything “10x cooler and better” and reported a critical bug: no raindrops fell, so players could not progress. A previous response claimed rain was fixed, but inspection found that the delivered server still used stationary anchored balls.

The latest v3 rebuild replaced that system and added all five requested improvements:
1. Better UI art and icons.
2. More dramatic map visuals and complete models.
3. Sound and music systems with original audio files.
4. More upgrades, gamepass and developer-product integrations.
5. A proper lobby/onboarding/tutorial flow.

If I attach the latest ZIP, inspect its actual contents and improve it rather than trusting these notes blindly. If no project is available, recreate the complete project from this specification. Make reasonable implementation decisions without repeatedly asking for confirmation.

## Priority zero: rain must make progression possible

Implement actual visible moving raindrops, not decorative particles or stationary pickups alone. Collecting rain must increase both spendable drops and earned storm energy, and let the player buy upgrades and evolve.

The latest working design:
- Six islands with 30 pooled drops each: 180 bounded collectible drops.
- Blue ordinary drops and golden drops worth 3x the island's base value.
- Every seventh slot is golden; this is free gameplay, not a paid random reward.
- Drops start around y=34–48, visibly descend at about 17 studs/second, and land at y=6.5 on islands whose ground surface is around y=3.5.
- Anchored parts move through a server Heartbeat system using elapsed time. Do not depend on physics ownership, gravity, or Touched events for correctness.
- Advance motion roughly every 0.05 seconds and check collection roughly every 0.15 seconds.
- Landed drops remain accessible. Claimed drops immediately become inactive, disappear, and recycle after about 2.5 seconds.
- Unclaimed slots refresh after about 22 seconds. Deleted/missing pooled parts recover automatically.
- Use trails and distinct colours to make falling rain obvious.
- Start rain independently of player DataStore loading.
- At startup, half the pool is already landed so new players can collect immediately.
- Keep the hub rain field directly beside spawn, around x=-21 to 21 and z=-30 to -9. Spawn is around (0, 4.4, -14); return-home/prestige arrival is around (0, 9, -18).
- Other islands use clear collection fields around radius 25–40 from their centers. Keep trees and monuments out of these fields and teleport arrivals.
- Expose Workspace diagnostics such as ActiveRainDrops and RainHeartbeat.
- Validate eligibility and distance on the server. Base collection radius is 7.5 studs, plus 3.5 per Magnet level. Immediately lock a claimed drop so two players cannot receive the same pickup.

Fix any observed startup, coordinate, serialization, loading or collection problem before adding optional polish. Verify a fresh player can earn 35 drops, buy Magnet, reach 60 energy, evolve, and travel.

## Core progression and economy

Separate spendable wallet Drops from earned storm energy Total. Spending wallet currency does not reduce cloud tier. Quest/daily/product wallet grants should not silently count as earned storm energy.

Cloud tiers and energy thresholds:
- Little Puff: 0.
- Fluffy Nimbus: 60.
- Rainmaker: 220.
- Thunderhead: 600.
- Frost Giant: 1,400.
- Tempest Crown: 3,000.

Island layout:
- Hub / Cloud Commons: center (0,0), tier 1, base drop value 1.
- Meadow / Drizzle Meadows: (-170,0), tier 1, value 2.
- Thunder / Thunder Peaks: (170,0), tier 3, value 4.
- Frost / Frostfall: (0,-170), tier 4, value 6.
- Cyclone / Cyclone Cove: (0,170), tier 5, value 9.
- Solar / Sunspire: (170,170), tier 6, value 14.

Free upgrades, using round(base × multiplier^currentLevel) for the next cost:
- Magnet: base 35, multiplier 1.85, maximum level 8; increases pickup radius.
- Rain Power / Yield: base 60, multiplier 2.0, maximum level 7; +30% reward multiplier per level.
- Sky Boots / Boots: base 50, multiplier 1.9, maximum level 6; speed 16 + 2 per level.
- Gold Amplifier / Lucky: base 90, multiplier 1.85, maximum level 6; golden rewards gain +25% per level.

Forecast Ascension:
- Requires 3,000 earned energy; maximum 20 Forecast Stars.
- Confirmation clearly explains the reset.
- Resets wallet, energy, upgrade levels and quest progress.
- Grants one permanent Forecast Star, adding +12% reward power per star.
- Returns the player safely to the starter field.
- Preserve purchased ownership and durable purchase receipts.

Daily quests, reset each UTC day:
- Pocket Drizzle: collect 40, reward 70 wallet drops.
- Rain Parade: collect 150, reward 200.
- Weather Wizard: collect 400, reward 550.
- Claims must be server-validated and usable only once per quest/day.

Daily gift: 22-hour cooldown, reward 125 + 20 per Forecast Star.

Storm Link co-op:
- Both players explicitly opt in; cancellation is available.
- Nearby consenting players within about 23 studs link.
- Both receive a 30-second +50% rain-power boost and a small earned reward.
- Cooldown about 100 seconds; readiness expires after about 35 seconds.
- No forced interactions.

Superstorms:
- First event begins around 60 seconds after server start in the hub.
- A named island gets 2x rain value for 45 seconds.
- Rotate islands, with about 120 seconds between events.
- Show location, duration and next-event countdown. Respect normal island tier gates.

## Models, map, cloud visuals and UI

Deliver the actual models inside the place. Use original self-contained geometry or properly licensed, verified assets. Do not rely on unspecified Toolbox models, external loaders or fake asset IDs.

The latest build had approximately 1,204 physical parts, including:
- Six floating islands, undersides, safe decks, paths, portal arches and readable signs.
- Clear outlined starter rain lane.
- Personal clouds that grow/change across all six tiers, with a face, rain effects, lightning accents and a final crown.
- Overhead storm canopies.
- Rainbow observatory and pool, forecast-shop kiosk, thunder spire/lightning, floating frost shards, cyclone spirals, solar shrine/corona and island halos.
- Six cloud colour styles earned through free play, plus a separate optional Aurora cosmetic with a halo.

Improve visual quality without sacrificing readable play spaces or mobile performance. Disable streaming for this compact layout unless you implement and test a reliable streaming-aware alternative.

Build a responsive HUD with:
- Wallet, tier/name, Forecast Stars and animated growth meter.
- Shop, quests, wardrobe, help, home, settings/extras.
- Original native UI icons for Magnet, Rain Power, Boots and Gold Amplifier.
- Pickup feedback, evolution notifications, event countdown and co-op status.
- Scrolling panels, reliable close controls, modal backdrop and stable controller selection during updates.
- Touch hit targets around 44 screen pixels or larger after scaling.
- Music/effects toggles and reduced-motion option. Avoid strobing and unnecessary camera shake.

Persistent four-step onboarding:
1. Collect 10 energy in the rain beside spawn.
2. Buy the first upgrade.
3. Reach 60 energy and evolve.
4. Visit Drizzle Meadows.
Infer reasonable tutorial state when migrating older saves; do not trap existing players with maxed upgrades in an impossible tutorial step.

## Audio and monetization

Include six usable original or licensed audio files:
- Music, Rain ambience, Pickup, Evolve, Click and Thunder.
The previous package included original synthesized mono WAV assets at 24 kHz, including a 32-second music loop.

Implement playback, sensible volumes and controls. Roblox assigns uploaded asset IDs and requires appropriate moderation/experience permissions. Do not invent IDs or claim audio works in a published game while all IDs are zero.

Optional monetization:
- Aurora Cloud cosmetic pass: permanent cosmetic colour/halo, no required progression advantage.
- Fixed developer product: 1,000 wallet drops, no random reward and no direct earned-energy increase.
- Pass/product IDs default to zero and unconfigured purchases are hidden.
- Show current prices returned by Roblox on the client.
- Use authoritative ownership checks and ProcessReceipt.
- Grant and persist the reward and receipt together before acknowledging.
- Prevent double grants on callback retry, receipt redelivery, reconnect or overlapping saves.
- Pause/serialize profile mutations during receipt transactions so purchases cannot overwrite fresh gameplay.
- Use a fresh candidate copy in each UpdateAsync callback invocation; retries must not repeatedly add currency.
- Failed persistence returns NotProcessedYet.
- Hide paid products for temporary Studio profiles.
- Include an editor-only SETUP_ASSET_IDS.luau helper and clear instructions for real account-specific setup.

## Saving, security and Roblox requirements

Check current official Creator Hub documentation rather than relying on remembered rules. Cover relevant publishing, security, DataStores, audio, passes, developer products and content requirements. Do not claim Roblox approval or complete policy certification.

Existing save key: GrowAStorm_v1. Preserve existing progress if updating the attached project. Normalize and migrate older fields safely.

The latest design uses:
- Server-authoritative currency, costs, tier gates, quests, cooldowns and rewards.
- Type/range validation and remote-action rate limiting.
- A session lease around five minutes.
- Autosaves about every 70 seconds, with three retries.
- A shutdown wait for pending saves, bounded around 25 seconds.
- Temporary playable profiles in Studio when DataStore access is unavailable.
- Safe rejection of live loading failures rather than overwriting an existing save.
- Saved tutorial, Gold Amplifier level, style, stars, quest state and receipt history.

Review and improve these mechanisms where needed. Server-distance checks alone are not comprehensive protection from client-controlled character exploits. Keep validation proportional, and avoid arbitrary bans.

## Architecture, export and known exporter defects

Runtime script locations:
- ReplicatedStorage / StormConfig — shared configuration.
- ReplicatedStorage / StormRain — pooling, falling motion and collection eligibility.
- ServerScriptService / StormServer — profiles, economy, clouds, travel, events, purchases and co-op.
- StarterPlayer / StarterPlayerScripts / StormClient — UI, feedback, settings and audio.

Earlier XML export used incorrect serialized part fields. When generating .rbxlx, use canonical serialized size, shape and packed Color3uint8 fields, with valid references and matching embedded source. Ensure the chosen reader recognizes the document header.

Deliver both:
- Grow_a_Storm.rbxl: native binary place, recommended to open.
- Grow_a_Storm.rbxlx: equivalent XML place.

Deserialize and inspect actual imported sizes, colours, shapes, script placement and source using a Roblox DOM tool such as Lune/rbx-dom, then generate/validate the binary place. XML parsing and delimiter counting alone are insufficient.

## Validation and completion

The previous v3 passed compilation of all four production scripts with Luau 0.742, actual-code headless integration tests, Roblox DOM deserialization/binary export, and package integrity checks. It was not run inside Roblox Studio. Treat previous results as history; rerun tests on YOUR final files.

Meaningful tests must cover:
- Falling position changes and reachable landing.
- Starter earnings and real wallet/energy increases.
- Immediate claim locking, recycling and missing-slot recovery.
- Tier and distance gates.
- Upgrade spending, golden multiplier, evolution and onboarding.
- Old-save migration, prestige and saved-profile reload.
- Two-player consenting Storm Link and cooldowns.
- Duplicate receipts, UpdateAsync callback retries and persistence failure.
- UI construction, shop/settings/wardrobe and notice interactions.
- Exact final source embedding, native place geometry and valid audio/ZIP assets.

If Roblox Studio is available, run actual Play, two-client tests, respawn, device/controller checks, performance profiling, private published saving, audio permissions and purchase tests. Use a separate test universe for persistence tests.

If Studio/account capabilities are unavailable, complete every possible implementation and offline validation, then clearly identify the remaining owner/Studio steps. Do not describe service mocks or DOM validation as a live Roblox playtest. Do not mark a test passed without running it. Fix test harness errors and inspect the final test exit status before packaging.

Deliver:
1. Both complete place formats.
2. Grow_a_Storm_Complete_Package.zip containing places, models, original audio, editable source, build/test utilities and actual test results.
3. README.md, SETUP_ASSET_IDS.luau and TESTING_AND_RELEASE.md with exact setup, troubleshooting and remaining release checks.
4. A brief final response with working file links and honest validation status.

Do not publish publicly, spend Robux or make live test purchases without my explicit instruction. Complete the work you can do before requesting any indispensable account action. Keep progress updates concise and keep working until the deliverables are complete.

