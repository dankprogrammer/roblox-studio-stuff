# Persistent 2.0 execution checklist

- [x] Inspect current native/source, preserve working rain, checkpoint before changes.
- [x] A/B: reusable premium UI tokens/components, expandable navigation, real screens.
- [x] C: 12 unique storm silhouettes × 3 stages; actual Blender mesh source/export.
- [x] D: rolling sanctuary, six authored locations, progressive laboratory plots.
- [x] E: cores/inventory/growth/environmental fit and clear resource economy.
- [x] F: ten deterministic mutations, compatibility/stack cap and engineering controls.
- [x] G: 12 upgradeable devices, five research branches, balance calculations.
- [x] H: goals/encyclopedia, visits/showcases/community/competition/chasing/prestige.
- [x] I: existing/new production tests, native validation, visual reviews, package.

Studio rendering, real multiplayer/device/performance, account-authorized mesh/audio
uploads, published saves and live purchase tests are unavailable and must remain
explicitly unrun. No public Roblox publishing or spending is authorized.

119 offline checks are executed. Conditional Studio/account steps above remain
unrun; completed implementation stages do not imply engine visual acceptance.
