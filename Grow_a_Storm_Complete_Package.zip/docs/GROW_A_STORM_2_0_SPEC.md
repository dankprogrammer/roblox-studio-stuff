# GROW A STORM 2.0 — PREMIUM VISUAL REDESIGN AND COMPLETE GAMEPLAY EXPANSION

## YOUR MISSION

You are now acting as the creative director, lead gameplay designer, senior Roblox engineer, professional 3D environment artist, and UI/UX lead for Grow a Storm.

The game is now FUNCTIONAL. Its rain system and basic gameplay work.

HOWEVER, THE CURRENT GAME IS FAR BELOW MY EXPECTED QUALITY.

My complaints:

1. The UI looks retro, outdated, amateurish, and visually unappealing.
2. The environment lacks the beautiful, polished atmosphere of successful Roblox simulator games.
3. The 3D models are far too simple, consisting of basic shapes without meaningful visual detail.
4. The gameplay is too shallow.
5. Progression is too linear and lacks interesting decisions.
6. There is insufficient variety, discovery, collecting, progression, and interaction.
7. Players have too few interesting goals after the initial gameplay.
8. The overall experience feels like a prototype rather than a fully developed Roblox game.

I want Grow a Storm to feel like a premium, professionally designed Roblox experience.

### VISUAL INSPIRATION

Primary reference: Grow a Garden.

Additional references: Steal An Egg and Steal a Brainrot.

Study the general principles behind their polished appearance, immediately readable interfaces, collectibility, progression, visual rewards, and multiplayer appeal.

DO NOT copy their proprietary assets, graphics, layouts, or branding.

Produce an original game with comparable care and quality.

### ABSOLUTE RULE

DO NOT ONLY WRITE PLANS OR MAKE SMALL COSMETIC CHANGES.

Actually improve the existing Roblox project.

Inspect the project before changing it, retain working systems, create a reversible backup, and implement the overhaul.

If you have access to Roblox Studio through MCP, use it to inspect and modify the actual game.

If you do not have access to Studio, modify the available project files and honestly identify anything requiring Studio verification.

---

# 1. COMPLETELY REDESIGN THE USER INTERFACE

The current UI is not acceptable.

I want the visual sophistication of a professionally art-directed Roblox game.

## Art direction

The new interface should be:

- Soft, vibrant, and friendly.
- Modern rather than retro.
- Inspired by the welcoming visual style of Grow a Garden.
- Beautifully rounded and carefully spaced.
- Consistent across every screen.
- Readable without occupying excessive screen space.
- Rich in visual feedback and smooth animations.
- Supported by an intentional visual identity.

Use a distinctive storm-themed palette:

- Soft sky blue
- Creamy white
- Fresh green
- Warm sunshine yellow
- Deep storm blue
- Lavender
- Occasional coral accents

Avoid harsh black boxes, random neon colours, large unstyled text labels, pixelated styling, and inconsistent gradients.

Create a reusable UI design system with consistent:

- Typography
- Corner radii
- Colour tokens
- Spacing
- Shadows and highlights
- Panel treatments
- Button states
- Icon treatments
- Animation timings

## Main HUD

Rebuild the entire HUD.

It should contain elegantly styled indicators for money, water, storm production and relevant objectives.

Use well-designed icons, subtle shadows, clear typography and excellent visual hierarchy.

The interface should remain clean during normal gameplay.

Create an expandable navigation system for:

- Storm Shop
- Storm Collection
- Equipment
- Mutations
- Quests
- Weather Forecast
- Upgrades
- Settings

Do not permanently fill the screen with enormous buttons.

## UI windows

Create polished interfaces for every major system.

Shop cards should include meaningful rarity treatments, attractive imagery or 3D previews, actual pricing, descriptions, affordability states and purchase feedback.

The storm collection should feel like a premium collectible encyclopedia.

Locked entries should appear mysterious while remaining readable.

Use animated transitions, tab navigation, hover states, responsive layouts and professional visual composition.

Implement genuine 3D previews using ViewportFrames where suitable.

Create unique interface components rather than relying on generic rectangles.

Every button must have an actual purpose and work correctly.

## Animation quality

Add tasteful spring-like animations, smooth transitions, card reveals, subtle button scaling, number counting, glow effects and rewarding unlock sequences.

Animations should improve clarity, not distract from gameplay.

## Required review

Inspect the actual UI in Roblox Studio on desktop and mobile layouts.

Capture and review screenshots if tooling permits.

Iteratively correct spacing, typography, alignment and styling.

Do not consider a UI complete simply because it functions.

I want a substantial visual transformation.

---

# 2. COMPLETELY OVERHAUL THE 3D MODELS

This is one of my highest priorities.

The current models look far too simple.

I do not want storms that resemble three spheres joined together, or machinery assembled from a few default Roblox blocks.

Create professionally art-directed, visually distinctive assets.

## Storm cloud modelling

Design impressive clouds with:

- Organic, asymmetrical silhouettes.
- Multiple sculpted-looking cloud volumes.
- Carefully layered forms.
- Visual depth and varied proportions.
- Soft shading.
- Distinct upper and lower regions.
- Different silhouettes for each storm type.
- Animated movement and subtle transformations.
- Appropriate particles and environmental effects.

A fluffy raincloud should look fundamentally different from a powerful thunderstorm.

A blizzard should not simply be a recoloured thundercloud.

A cosmic storm should have unique geometry, motion and effects.

## Model production

Use proper MeshParts or imported original meshes when the available tools support them.

If Blender or another modelling workflow is available, use it to create higher-quality original models.

If external modelling is not available, construct carefully designed layered models with Roblox primitives and available procedural techniques.

Do not falsely claim to have generated high-quality meshes.

Use only appropriately licensed or original assets.

## Minimum storm collection

Create at least 12 visually distinct storm types:

1. Fluffy Drizzle
2. Silver Raincloud
3. Tropical Downpour
4. Thunderhead
5. Crystal Blizzard
6. Electric Tempest
7. Crimson Cyclone
8. Golden Monsoon
9. Aurora Storm
10. Celestial Hurricane
11. Void Tempest
12. Cosmic Superstorm

These are suggested creative names and themes. Improve them if necessary.

Each needs its own:

- Model silhouette.
- Colour identity.
- Particle effects.
- Rarity.
- Production statistics.
- Growth progression.
- Collection entry.
- Unlock path.
- Special characteristics where appropriate.

Develop at least three visibly different growth stages for each storm.

The models should look significantly different as they develop.

An advanced storm should look genuinely impressive when viewed from across the map.

---

# 3. REDESIGN THE MAP INTO A BEAUTIFUL STORM SANCTUARY

The world must become visually memorable.

Move away from flat, empty, generic simulator environments.

Create a beautifully landscaped, storm-themed valley or floating sanctuary.

## Environment requirements

Include:

- Organic terrain and rolling hills.
- Attractive pathways.
- Lush grass and vegetation.
- Detailed stylised trees.
- Beautiful water features.
- Carefully composed flower beds.
- Decorative stonework.
- Weather-themed machinery.
- Atmospheric cloud formations.
- Distinctive shops and market stalls.
- Environmental animation.
- Warm, beautifully balanced lighting.
- A coherent colour palette.

Keep the environment bright and inviting, even though the game involves storms.

## Player plots

Create attractive private storm cultivation areas.

These should feel like mini weather laboratories or sky gardens.

Each plot should:

- Have several storm-growing platforms.
- Visibly evolve as the owner progresses.
- Allow meaningful placement or customisation.
- Display its owner's name.
- Contain attractive equipment.
- Showcase the owner's rarest storms.
- Support unlocking additional areas.

As players progress, their plots should transform from small cloud gardens into impressive weather research facilities.

The difference between a beginner plot and an advanced player's plot should be visually obvious.

## Central area

Create:

- Weather Market
- Storm Research Laboratory
- Equipment Workshop
- Storm Index Pavilion
- Prestige Observatory
- Community Event Area

Give each location attractive architecture and original visual details.

Everything should feel like it belongs to one carefully designed world.

---

# 4. EXPAND THE CORE GAMEPLAY INTO A DEEP PROGRESSION SYSTEM

The current gameplay is far too basic.

A loop of collecting rain, earning money and purchasing upgrades is not enough.

Keep that loop as the foundation, but build multiple interconnected progression systems around it.

## New core gameplay

Players are storm cultivators.

They obtain Storm Cores, grow them into cloud formations, manipulate weather conditions, discover mutations, harvest their resources, and expand their collections.

Core loop:

Obtain Storm Core → Place It → Grow Cloud → Collect Resources → Improve Conditions → Unlock Evolution → Discover Mutations → Upgrade Equipment → Expand Plot → Obtain Rarer Storms.

The player should always have meaningful decisions and several achievable goals.

## Storm acquisition

Create a Weather Market selling different Storm Cores.

More advanced cores unlock through progression, research, achievements and special events.

Different cores should have genuinely different characteristics.

Some might produce resources quickly.

Others might take longer but create high-value weather phenomena.

Others could be particularly useful for discovering special mutations.

Give every storm category a reason to exist.

## Storm growth

Storms should progress through multiple growth stages.

Growth should depend on understandable factors such as:

- Water
- Temperature
- Humidity
- Atmospheric charge
- Wind intensity
- Equipment bonuses

These should have gameplay consequences rather than just decorative statistics.

Players should be able to influence their clouds by choosing suitable equipment and conditions.

## Resource economy

Create a coherent economy with clear purposes for different resources.

Suggested structure:

Water — primary early-game production resource.

Coins — main purchasing currency.

Atmospheric Energy — resource from advanced storms and special weather interactions.

Research Points — earned through discoveries, experiments and quests.

Avoid creating unnecessary currencies purely to increase complexity.

Clearly explain resource sources and sinks.

Balance production and pricing with actual calculations.

---

# 5. CREATE AN ADVANCED STORM MUTATION SYSTEM

This should become one of Grow a Storm's signature features.

Storms can develop rare, visually impressive mutations under particular conditions.

Examples:

- Charged — pulsing electric arcs.
- Frozen — ice crystals and frosty particles.
- Golden — metallic golden highlights.
- Rainbow — prismatic lighting.
- Volcanic — warm glowing fissures and ash effects.
- Celestial — luminous stars and orbiting particles.
- Corrupted — dark swirling energy.
- Prismatic — colourful refracted light.
- Aurora — flowing ribbons of atmospheric light.
- Eclipse — darkened central cloud with a glowing corona.

Mutations should affect:

- Visual appearance.
- Resource production.
- Collection rarity.
- Special abilities where relevant.
- Potential evolution paths.

## Mutation depth

Some mutations should result from player-controlled environmental conditions.

Others can occur occasionally through clearly disclosed probabilities.

For example:

A sufficiently charged thundercloud during an electrical event might develop a Charged mutation.

A raincloud exposed to extreme cold could become Frozen.

Make experimenting with conditions an enjoyable process.

Some compatible mutations may combine into new visual variants.

Create a coherent compatibility and stacking system, with sensible limits to avoid excessive multipliers.

The goal is to encourage experimentation and collecting, not arbitrary luck.

Do not use paid random loot boxes.

---

# 6. ADD WEATHER ENGINEERING — THE GAME'S UNIQUE FEATURE

I want Grow a Storm to offer something beyond ordinary simulator mechanics.

Create a Weather Engineering system.

Players can control local atmospheric conditions within their plots using equipment.

Suggested variables:

- Temperature
- Humidity
- Wind
- Electrical Charge

## Weather Engineering Laboratory

Players can construct or upgrade machinery such as:

- Humidity Condenser
- Thermal Regulator
- Lightning Collector
- Wind Amplifier
- Atmospheric Stabiliser
- Storm Fusion Chamber

These devices should have unique original 3D models, operating animations and clear upgrades.

Different equipment combinations should affect storms differently.

For example:

High humidity + strong electrical charge may help produce advanced thunderstorms.

Low temperature + high humidity may enable blizzard evolution.

Strong winds + sufficient atmospheric energy may support cyclone formation.

## Experimentation and discovery

Allow players to discover recipes or atmospheric combinations.

Unlock successful experiments in a Weather Research Journal.

Provide clues and progression goals so discoveries are not based entirely on blind guessing.

This system should create a satisfying sense of mastery as players learn to produce better storms.

---

# 7. CREATE DEEP, MULTI-LAYERED PROGRESSION

Design distinct early-game, mid-game and endgame progression.

## Early game — First 10 minutes

The player should:

- Receive their first Storm Core.
- Grow a cloud.
- Collect water.
- Earn money.
- Buy their first upgrade.
- Obtain a second cloud.
- Discover a basic environmental interaction.
- See an exciting future unlock.

Make these milestones intuitive and achievable.

Avoid lengthy tutorials.

## Mid-game — First few hours

Introduce:

- Multiple storm slots.
- Rare Storm Cores.
- Atmospheric equipment.
- Mutations.
- Plot expansions.
- Quests.
- Research upgrades.
- Weather events.
- Meaningful collection goals.

Progression should require strategic choices rather than only waiting for a number to increase.

## Long-term progression

Develop:

- Advanced storm evolution.
- Rare mutation combinations.
- Specialised equipment builds.
- Additional plot areas.
- Research branches.
- Challenging achievement collections.
- Prestige progression.
- High-tier storms.
- Rotating events.
- Collection completion rewards.

Create substantial content for players who continue playing over many sessions.

## Prestige system

Prestige should provide meaningful permanent benefits and new options.

Avoid making players repeatedly perform the exact same tasks without meaningful changes.

Prestige may unlock:

- New plot architecture.
- Additional storm slots.
- Advanced research.
- Special equipment.
- Unique cosmetic effects.
- New weather regions.

Prestige must not accidentally destroy valuable collected storms or data.

---

# 8. CREATE MORE INTERESTING SHOPS AND EQUIPMENT

The existing shops should feel like actual attractive in-world locations.

## Weather Market

Create an animated merchant shop with an organised catalogue and periodically changing selection.

Include clear stock information, progression requirements and rarity.

Ensure key progression items remain obtainable without relying on limited shop refreshes.

## Equipment Workshop

Create approximately 10–15 functional equipment types across several progression stages.

Each device must have:

- A distinctive model.
- A genuine mechanical effect.
- An upgrade path.
- A clear description.
- Visible operational feedback.

## Research Centre

Create a research tree with several meaningful branches.

For example:

Production — increases efficiency.

Meteorology — expands environmental controls.

Evolution — unlocks advanced storm forms.

Engineering — improves machinery and plot capabilities.

Collection — unlocks discovery bonuses.

Research should allow different playstyles.

Avoid creating one overwhelmingly superior upgrade route.

---

# 9. MAKE MULTIPLAYER MEANINGFUL

Successful Roblox simulator games often have memorable social moments.

Grow a Storm needs visible reasons to visit other plots and interact with players.

## Social systems

Implement:

- Plot visiting.
- Storm showcases.
- Public collection achievements.
- Collaborative weather events.
- Server-wide storm discoveries.
- Friendly production competitions.
- Safe trading, if it can be implemented securely.

## Global storm events

Occasionally introduce spectacular weather systems visible across the whole map.

Examples:

- Golden Sky
- Thunder Surge
- Frozen Front
- Aurora Night
- Celestial Convergence

Events should temporarily change the atmosphere and offer interesting goals.

Create dramatic but performant environmental transformations.

## Original competitive feature

Design a system called Storm Chasing.

A rare travelling weather formation appears in the shared world.

Players can participate in a short skill-based activity to collect atmospheric energy and contribute to stabilising or researching it.

Provide participation rewards and additional recognition for skillful play.

Avoid winner-takes-all mechanics that make other participants feel they wasted their time.

Consider optional friendly competitive mechanics inspired by the excitement of multiplayer collection games, without copying their stealing systems.

---

# 10. ADD QUESTS, DISCOVERIES AND COLLECTION GOALS

Create a quest system supporting:

- Short introductory objectives.
- Research challenges.
- Mutation discovery tasks.
- Storm evolution achievements.
- Equipment progression objectives.
- Longer-term collection milestones.

Avoid repetitive quests that are just "Collect 10,000 more water".

Encourage players to explore systems and make interesting choices.

## Storm Encyclopedia

Create an attractive collection interface tracking:

- Discovered storm types.
- Mutation variants.
- Highest achieved growth stages.
- Rare achievements.
- Research discoveries.
- Collection completion rewards.

Rare discoveries should trigger impressive but tasteful celebration animations.

The collection should provide substantial optional completion goals.

---

# 11. MAKE EVERY ACTION FEEL SATISFYING

Improve moment-to-moment gameplay.

Implement:

- Beautiful growth animations.
- Smooth cloud transformations.
- Distinct collection effects.
- Animated currency counters.
- Equipment activation effects.
- Different weather soundscapes.
- Visually impressive evolution sequences.
- Rich mutation discovery effects.
- Clear purchasing feedback.
- Strong audiovisual distinction between rarity tiers.

The environment should respond visibly to gameplay progression.

However, avoid excessive screen shake, flashing, or constant visual clutter.

Provide settings to reduce visual effects and sounds.

---

# 12. PROFESSIONAL TECHNICAL IMPLEMENTATION

Preserve the existing working gameplay unless replacing it is necessary.

Create a maintainable, modular architecture.

Suggested systems:

- StormDefinitions
- StormGrowthService
- StormMutationService
- WeatherSimulationService
- WeatherEngineeringService
- ResourceEconomyService
- InventoryService
- ShopService
- QuestService
- ResearchService
- PrestigeService
- PlotService
- EventService
- DataPersistenceService
- UIComponentLibrary

Use appropriate ModuleScripts and server/client separation.

The server must authoritatively validate purchases, resource rewards, progression, mutations and trading.

Safely migrate existing player data.

Avoid uncontrolled RemoteEvents, expensive loops and unnecessary physical objects.

Use efficient visual effects, object reuse and appropriate replication.

Test on mobile and desktop.

Follow current Roblox Creator Hub guidance.

---

# 13. IMPLEMENT IN STAGES, BUT ACTUALLY FINISH THE WORK

This is a production assignment, not a brainstorming request.

Before implementing, inspect the existing game and produce a concise technical audit.

Then execute the following stages:

STAGE A — Establish a cohesive art direction and reusable premium UI design system.

STAGE B — Replace the entire existing UI and verify its appearance.

STAGE C — Rebuild the cloud models and improve their visual evolution.

STAGE D — Rebuild the map and player plots.

STAGE E — Add the expanded storm progression and collection systems.

STAGE F — Implement mutations and Weather Engineering.

STAGE G — Add research, equipment and deeper economy balancing.

STAGE H — Implement social features, events, quests and prestige.

STAGE I — Perform gameplay balancing, optimisation and comprehensive testing.

Maintain functional gameplay throughout.

If the work is larger than one Codex session, maintain a persistent checklist and architecture notes in the project, so the next session can continue accurately.

Do not abandon incomplete stages after producing a summary.

## Required tests

Verify:

- Existing rain spawning and collection still work.
- Existing player data is preserved.
- Players can obtain and grow new Storm Cores.
- Every added storm type is obtainable.
- Every added upgrade has a real effect.
- Mutations are applied correctly.
- Equipment affects environmental conditions.
- UI buttons and displays respond correctly.
- Resources cannot be duplicated.
- Prestige works safely.
- Multiplayer plot ownership remains stable.
- New players can understand the game.
- Progression cannot become permanently blocked.
- Models and UI work on supported devices.

Do not claim to have performed tests that have not actually run.

---

# 14. QUALITY ACCEPTANCE CRITERIA

I will judge the finished result against these requirements:

VISUAL QUALITY:
The game must look significantly more polished, colourful, detailed and professionally art-directed than the current version.

UI QUALITY:
The interface must feel like it belongs in a premium modern Roblox simulator rather than a basic student project.

MODEL QUALITY:
Advanced clouds should have intricate silhouettes, original visual details and spectacular transformations, not basic geometric placeholders.

GAMEPLAY DEPTH:
Players should have multiple interconnected progression systems, meaningful decisions and an exciting range of achievable goals.

COLLECTIBILITY:
There must be substantial storm variety, memorable mutations and a compelling collection system.

ORIGINALITY:
Grow a Storm should have a distinctive identity through storm cultivation and Weather Engineering.

TECHNICAL QUALITY:
No critical gameplay regressions, broken buttons, disappearing storms or progression-blocking issues.

REPLAYABILITY:
Players should have reasons to return because of interesting discoveries, collection goals, experimentation, new upgrades and social play.

ACCESSIBILITY:
New players must understand the core mechanics immediately, even though advanced systems have depth.

MONETISATION:
Keep progression fair, transparent and enjoyable without mandatory spending or manipulative pressure.

---

# FINAL INSTRUCTION

The existing game works, but its overall quality is disappointing.

I am not asking for another basic simulator with a different colour scheme.

I want a substantial transformation into an original, visually impressive, content-rich Roblox game.

Do not settle for simple models, generic UI, empty maps or shallow progression.

Make bold improvements.

Build the actual systems, models and interfaces.

Review the results visually wherever tools allow.

Iterate on work that does not meet the required quality.

Treat Grow a Storm 2.0 like a real commercial-quality game undergoing a major development overhaul.

START BY AUDITING THE CURRENT PROJECT, THEN PROCEED WITH IMPLEMENTATION.