# GROW A STORM — COMPLETE GAME OVERHAUL & REBUILD

## YOUR ROLE

You are an elite Roblox game development team consisting of:

- A senior Roblox Luau programmer
- A professional Roblox environment and map designer
- A UI/UX designer specialising in successful Roblox simulator and tycoon games
- A gameplay systems designer
- A VFX and animation specialist
- A Roblox QA engineer
- A performance optimisation specialist

You are working on my existing Roblox game called **Grow a Storm**.

**THIS IS NOT A NEW PROJECT. YOU MUST WORK ON AND IMPROVE MY EXISTING GAME.**

I am extremely dissatisfied with its current quality. The UI looks amateurish, the map feels underdeveloped, the gameplay is not engaging enough, and several essential mechanics are broken.

The biggest existing bug is that rain droplets do not actually fall or spawn correctly, making progression impossible.

Your mission is to transform Grow a Storm into a polished, attractive, addictive-to-play Roblox experience that feels comparable in production quality, presentation, and accessibility to popular games such as Steal An Egg, Steal a Brainrot, and Grow a Garden.

Use these games as **visual and gameplay-quality references, not as assets or designs to copy directly**. Grow a Storm must retain its own original identity.

Do not merely suggest improvements. IMPLEMENT THEM.

---

# PHASE 1 — AUDIT THE EXISTING GAME

Before rebuilding anything:

1. Inspect the entire existing project, including Explorer hierarchy, scripts, modules, RemoteEvents, UI, terrain, map, lighting, models, data systems, and gameplay mechanics.
2. Identify every critical gameplay bug, especially why rain does not spawn or fall.
3. Check for broken object references, missing dependencies, incorrect script locations, runtime errors, faulty networking, and unfinished features.
4. Determine which components are worth preserving and which should be replaced completely.
5. Preserve working player data and progression where possible.
6. Create a backup or reversible checkpoint before destructive changes.

If an existing system is fundamentally flawed, rebuild it properly instead of applying a temporary patch.

You have creative permission to significantly redesign the game.

**Do not preserve poor-quality design simply because it already exists.**

# PHASE 2 — COMPLETELY REDESIGN THE MAP

The existing map is not visually impressive enough.

I want a complete environment overhaul inspired by the visual polish and readability of popular Roblox tycoon games.

## Visual direction

The map should be:

- Bright, colourful, cheerful, and visually satisfying.
- Clean and stylised, with smooth geometry.
- Filled with vibrant grass, colourful paths, clouds, trees, props, and interesting landmarks.
- Easy for young Roblox players to navigate.
- Attractive in screenshots and gameplay videos.
- Immediately recognisable as a storm-themed game.

Avoid bland baseplates, ugly default parts, empty spaces, untextured blocks, and repetitive placeholder geometry.

## Main map layout

Create a carefully designed multiplayer map featuring:

**1. Central plaza**

A visually striking central area containing:

- A large decorative storm-themed landmark.
- Attractive pathways.
- Weather-themed decorations.
- An upgrade shop.
- A progression/rebirth area.
- A collection or storm index area.
- Clear signs, interactive areas, and environmental details.

**2. Individual player plots**

Create approximately 6–8 plots arranged around the central area.

Each plot should have:

- A clearly visible ownership sign.
- An attractive, coloured boundary.
- A designated area for growing storm clouds.
- Space for future upgrades.
- Visible storm progression.
- An easy-to-understand collection area.
- A distinctive but consistent visual style.

Automatically assign plots when players join and release them when players leave.

**3. Weather-themed areas**

Add environmental details such as:

- Animated decorative clouds.
- Small ponds and streams.
- Stylised rocks.
- Colourful flowers and plants.
- Trees with attractive canopies.
- Weather observation equipment.
- Windmills or weather vanes.
- Lightning-themed structures.
- Floating atmospheric decorations.

Use thoughtful placement rather than filling the map with random objects.

## Environment polish

Implement:

- Attractive Lighting and Atmosphere settings.
- Balanced sunlight and shadows.
- A beautiful sky.
- Tasteful Bloom and ColorCorrection.
- Subtle environmental animations.
- Properly sized models.
- Consistent materials and colours.
- Decorative details that do not interfere with gameplay.

The finished environment should look like an actual successful Roblox simulator, not a basic Studio experiment.

# PHASE 3 — REBUILD THE ENTIRE UI

The current UI needs a complete redesign.

Take inspiration from the visual language of successful Roblox simulators and tycoons, particularly Steal An Egg.

I want a modern, colourful, extremely polished interface.

## Visual style

Use:

- Rounded buttons and panels.
- UIStroke for clean outlines.
- Gradients where appropriate.
- Large, readable typography.
- Bright accent colours.
- Strong visual hierarchy.
- Satisfying hover and press animations.
- Consistent spacing.
- Clear icons.
- Professional layout and alignment.

Avoid default grey Roblox buttons, oversized obstructive windows, tiny unreadable text, and inconsistent styling.

## Main HUD

Create an attractive HUD displaying:

- Current money.
- Water collected.
- Storm level or overall progression.
- Current weather event.
- Important upgrades.
- Navigation to the shop, storm collection, settings, and rebirth systems.

Keep the screen clean. The world itself should remain visible.

## Shop UI

Completely redesign the shop.

Include:

- Attractive cards.
- Clear upgrade names.
- Prices and descriptions.
- Upgrade levels.
- Visual indication of affordability.
- Animated purchase feedback.
- Clear locked/unlocked states.

All buttons must actually work.

## Storm collection UI

Create a beautiful interface showing collected storm types.

Each entry should display:

- Storm name.
- Storm rarity.
- Storm appearance or preview where supported.
- Production statistics.
- Discovery status.

## Notifications and feedback

Add satisfying visual feedback for:

- Collecting water.
- Earning money.
- Purchasing upgrades.
- Unlocking storms.
- Encountering rare weather.
- Reaching milestones.
- Insufficient currency.

Use animations and sounds without overwhelming the player.

## Responsiveness

The UI must work properly on:

- Desktop
- Mobile
- Tablet
- Supported console input

Use appropriate Roblox UI constraints and scaling.

Test for clipping, overlapping buttons, poor readability, and unusable touch controls.

**No decorative button is allowed to pretend to work. Every interactive control must have genuine functionality.**

# PHASE 4 — FIX AND REBUILD THE RAIN SYSTEM

THIS IS THE HIGHEST-PRIORITY GAMEPLAY FIX.

Currently, rain droplets do not fall properly and players cannot progress.

This is completely unacceptable.

You must investigate and permanently fix the issue.

## Required rain behaviour

When a player receives or grows a storm cloud:

1. The cloud must appear visibly above its designated growing area.
2. Rain must visibly fall from the cloud.
3. Collectible droplets must spawn reliably.
4. Droplets must visibly move downward.
5. Players must be able to collect them.
6. Collecting droplets must grant the correct resources.
7. Resources must update the HUD immediately.
8. Collected resources must enable upgrades and further progression.

A new player should see their first collectible rain within approximately five seconds of receiving their starter cloud.

## Technical implementation

Build a reliable server-authoritative rain and collection system.

Separate decorative rainfall VFX from gameplay-critical collectible droplets.

Use performant visual techniques such as ParticleEmitters for realistic-looking rainfall, but do not depend on particle collisions for rewards.

Implement actual gameplay collectible instances or validated server-side pickup records with client-side animations.

Use appropriate object pooling, cleanup, spawn limits, and lifecycle management.

Make sure:

- Rain works for every player's storm.
- Rain continues throughout normal gameplay.
- Rain remains functional when multiple storms are active.
- Multiplayer clients see consistent gameplay state.
- Players cannot duplicate currency through RemoteEvent exploits.
- Droplets never accumulate indefinitely.
- Droplets are visible and collectible.
- Rain does not silently stop after an upgrade, respawn, or character reset.

If the rain system fails, implement meaningful error logging and recovery.

Create automatic tests for rain spawning, collection, and rewards.

**Do not declare this phase complete until you have verified that a new player can collect droplets and progress through the game.**

# PHASE 5 — IMPROVE THE CORE GAMEPLAY LOOP

The game must become enjoyable, satisfying, and easy to understand.

Maintain the core fantasy:

**Grow small clouds into increasingly powerful and valuable storms.**

## Intended progression loop

1. Player joins and receives a starter cloud.
2. The cloud produces visible collectible rainfall.
3. Player collects water.
4. Player converts or uses water to earn and spend currency.
5. Player upgrades their storm.
6. Their cloud becomes visibly larger and more impressive.
7. Better storms produce additional resources.
8. Player unlocks new storm types.
9. Player expands their storm collection and production.
10. Player progresses toward powerful weather events and endgame milestones.

The first few minutes should feel immediately rewarding.

## Starter experience

Create a simple and effective onboarding sequence.

New players should understand what to do without reading a wall of text.

Use subtle arrows, highlights, and objective prompts.

Example:

"Collect your first 5 raindrops!"

After completing the objective, guide the player to their first upgrade.

## Storm growth system

Clouds should visually evolve as they become stronger.

For example:

- Level 1: Tiny fluffy cloud.
- Level 2: Larger cloud producing more rain.
- Level 3: Dense grey raincloud.
- Level 4: Storm cloud with subtle lightning.
- Level 5: Powerful animated thunderstorm.

Higher-level storms should visibly produce stronger effects.

Use actual geometry, particle effects, animation, lighting, and controlled sound design to communicate progression.

Do not just increase a number in the UI.

## Storm rarity and variety

Develop distinct collectible storms with different appearances.

Examples:

- Sunny Drizzle
- Rain Cloud
- Thundercloud
- Blizzard
- Electric Storm
- Aurora Storm
- Solar Tempest
- Cosmic Storm

Assign balanced progression requirements and production values.

Special storms should have unique visual effects.

Make all base gameplay progression achievable without spending Robux.

Do not implement paid random loot boxes or gambling-like purchases.

## Upgrades

Implement meaningful upgrades, potentially including:

- Faster rainfall.
- More water per collection.
- Increased cloud capacity.
- Improved storm growth.
- Additional storm slots.
- Higher storm production.

Upgrades should have clear costs, measurable improvements, and noticeable feedback.

## Weather events

Implement periodic events that make the world feel alive.

Examples:

- Heavy Rain: Increased rainfall.
- Thunderstorm: Temporary production bonus.
- Rainbow Weather: Special visual atmosphere and gameplay bonus.
- Blizzard: Unique particles and themed rewards.

Include readable event announcements and countdowns.

Events should enhance the core gameplay without interrupting or breaking ordinary progression.

## Long-term goals

Implement or improve a balanced rebirth/prestige system if it fits the existing game.

Create meaningful milestones and reasons to unlock additional storm types.

Avoid excessive grinding or unfairly slow progression.

# PHASE 6 — MAKE THE GAME VISUALLY SATISFYING

Visual satisfaction is extremely important.

I want the game to feel alive.

## Cloud models

Replace ugly or placeholder clouds with attractive stylised cloud models.

Use combinations of smooth shapes, layered geometry, gradients where feasible, and animation.

Each storm should be visually recognisable.

## Rain effects

Create visually appealing rain using:

- Animated rainfall particles.
- Distinct collectible droplets.
- Splash effects on the ground.
- Small collection animations.
- Weather-specific particle variations.

Different storms should feel different.

## Animations

Include polished animations for:

- Cloud growth.
- Upgrades.
- Rain collection.
- Purchases.
- Storm unlocks.
- Weather changes.
- UI opening and closing.

Use TweenService and other appropriate Roblox systems.

## Sound design

Add suitable sounds for:

- Collection.
- Purchases.
- Unlocks.
- Rain.
- Thunder.
- UI interaction.

Use only original, appropriately licensed, or Roblox-permitted sound assets.

All effects should be balanced and performant.

# PHASE 7 — FIX ALL EXISTING BUGS

Audit and repair every broken essential system.

Specifically investigate:

- Rain not spawning.
- Clouds failing to generate.
- Currency not increasing.
- Upgrades not applying.
- Buttons not responding.
- Incorrect remote communication.
- Broken spawning and plot ownership.
- Duplicate UI.
- Data failing to save.
- Incorrect player progression.
- Infinite yields.
- Script errors.
- Missing assets and references.
- Memory leaks.
- Multiplayer desynchronisation.

Use appropriate server/client separation.

Never trust client-supplied currency amounts or purchases.

Add input validation, rate limiting, and error handling where necessary.

Remove redundant, abandoned, or conflicting scripts once their functionality has been safely replaced.

Do not simply disable error messages.

Fix the underlying problem.

# PHASE 8 — DATA SAVING AND MULTIPLAYER

The experience must be stable across sessions.

Implement or repair persistent player data for:

- Currency.
- Unlocked storms.
- Owned upgrades.
- Progression levels.
- Rebirths, if implemented.
- Relevant settings.

Use Roblox DataStoreService correctly, including protected calls, controlled retries, and safe update logic.

Prevent duplicate rewards and avoid overwriting existing live player progress.

Ensure plot ownership, storm spawning, and collection work with multiple users simultaneously.

If multiplayer tests reveal a problem, fix it before claiming completion.

# PHASE 9 — PERFORMANCE OPTIMISATION

The game must look polished without being unnecessarily demanding.

Optimise for regular Roblox devices, including mid-range phones.

Prioritise:

- Efficient particle effects.
- Reasonable instance counts.
- No uncontrolled object spawning.
- Clean event connection management.
- Efficient animations.
- Proper instance cleanup.
- Limited expensive per-frame loops.
- Appropriate visual quality settings.

Rain effects must not cause massive FPS drops.

Avoid creating thousands of individual physics-based raindrops.

Use lightweight visual rainfall and a manageable number of genuine collectibles.

# PHASE 10 — ACTUAL IMPLEMENTATION AND TESTING

IMPORTANT: DO NOT STOP AFTER WRITING A PLAN.

You must carry out the implementation.

If Roblox Studio access is available through MCP or another authorised connection, inspect and modify the live project using those tools.

If working through a Rojo-style repository, make the actual file changes and produce any necessary map-building scripts or project assets.

Do not pretend to have inspected, rendered, or tested the Roblox Studio place if you lack access to it.

Use Roblox Creator Hub documentation to verify relevant APIs and recommended practices.

## Required testing

Test all of the following:

1. A player joins and receives a valid plot.
2. The starter cloud appears.
3. Collectible raindrops spawn and visibly fall.
4. The player can collect raindrops.
5. The correct resources are awarded.
6. The player can purchase their first upgrade.
7. The upgraded cloud changes visually and mechanically.
8. Storm production continues afterward.
9. The shop opens and purchases work.
10. The HUD updates correctly.
11. Data persists after leaving and rejoining, when test storage is available.
12. Multiple players can occupy different plots and progress independently.
13. Respawning does not break gameplay.
14. Weather events do not permanently interrupt production.
15. All primary UI screens work on different display sizes.

Where possible, perform automated tests and Roblox Studio multiplayer playtests.

Inspect Output errors and correct the underlying causes.

## Acceptance criteria

The rebuild is only successful when:

- The map is substantially more polished.
- The old UI has been replaced by a professionally designed interface.
- Rain actually falls.
- Raindrops can be collected reliably.
- Players can progress from the starter cloud to upgrades.
- Storms visibly evolve.
- All main gameplay systems function.
- Multiplayer systems are stable.
- The game's visual identity feels coherent.
- The game is enjoyable from the first minute.
- No critical bugs prevent progression.

## REQUIRED WORKFLOW

Complete this project in the following order:

**Priority 1:** Fix the fundamental rain spawning and collection mechanics.

**Priority 2:** Ensure the complete core progression loop works.

**Priority 3:** Rebuild and polish the map.

**Priority 4:** Completely replace the UI.

**Priority 5:** Improve cloud models, animations, and environmental effects.

**Priority 6:** Add gameplay depth and longer-term progression.

**Priority 7:** Optimise and perform multiplayer and regression testing.

Keep the project functional after each stage.

Do not spend all your effort on the first stage while leaving the remaining game unfinished.

Do not repeatedly ask for minor design decisions. Make professional choices that fit the visual direction I have described.

## FINAL DELIVERABLE

I want an actual substantially improved Grow a Storm game, not a collection of disconnected code snippets.

When finished, provide:

1. A summary of everything changed.
2. The major bugs discovered and how they were resolved.
3. The final script/module structure.
4. A list of newly implemented gameplay systems.
5. Details of map and UI improvements.
6. Results of the tests actually performed.
7. Any known remaining issues.
8. Exact instructions for opening and playing the updated experience in Roblox Studio.

If a required change cannot be completed with the available tools, explain the exact limitation and finish as much implementation as possible.

Do not claim the game is release-ready without sufficient verification.

### FINAL QUALITY EXPECTATION

Imagine Grow a Storm is being developed by a small professional Roblox studio preparing a major public launch.

It should not look like a student's first Roblox project.

It should have the colourful atmosphere, satisfying gameplay feedback, clarity, and level of polish that make popular Roblox simulator games enjoyable.

Use your judgment as an experienced developer.

**My final instruction: Stop treating this project as a prototype. Turn Grow a Storm into a real, polished, fully functioning Roblox game.**