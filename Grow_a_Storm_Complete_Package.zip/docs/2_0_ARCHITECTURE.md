# Grow a Storm 2.0 implementation contract

Keep existing StormRain/Profiles/Plots/Link safeguards and GrowAStorm_v1 keys.
StormDefinitions owns deterministic 12-core/12-device/10-mutation/5-research/
11-goal catalogs. StormScience owns profile v6 migration, environmental fit,
growth, market/engineering/research/recipe/expansion/journal rules. Old IDs and
collected cores are grandfathered. Water remains lifetime; Reservoir is the
new spendable stored-water sink. Atmosphere and ResearchPoints have explicit
advanced-rain/event/discovery sources. StormChase owns bounded server-time,
distance/cooldown validated reflex rounds and one-time participation rewards.
StormModelFactory owns original 36 procedural growth designs shared by runtime,
previews, exports and Blender mesh authoring. StormUI owns design tokens/components.
Server wiring serializes all new mutations through the existing profile mutex.
Trading is intentionally omitted (optional in the specification); no unsafe or
nonfunctional trading button will be exposed. Mesh files are original Blender
exports; native detailed models remain playable until the owner imports the supplied original models. Never claim imported MeshParts or engine playtests without proof.

Cloud/device native template libraries are server-stored to avoid client replication.
Fractional private-rain carry ensures small growth/device/research output increases
actually pay over repeated pickups; remaining fractions persist across saves.
New-type planting resets bay growth/mutations without deleting encyclopedia records.
